import { tokens } from "../theme";

export const mockDataTeam = [
  {
    id: 1,
    name: "Jon Snow",
    email: "jonsnow@gmail.com",
    age: 35,
    phone: "(665)121-5454",
    access: "admin",
  },
  {
    id: 2,
    name: "Cersei Lannister",
    email: "cerseilannister@gmail.com",
    age: 42,
    phone: "(421)314-2288",
    access: "manager",
  },
  {
    id: 3,
    name: "Jaime Lannister",
    email: "jaimelannister@gmail.com",
    age: 45,
    phone: "(422)982-6739",
    access: "user",
  },
  {
    id: 4,
    name: "Anya Stark",
    email: "anyastark@gmail.com",
    age: 16,
    phone: "(921)425-6742",
    access: "admin",
  },
  {
    id: 5,
    name: "Daenerys Targaryen",
    email: "daenerystargaryen@gmail.com",
    age: 31,
    phone: "(421)445-1189",
    access: "user",
  },
  {
    id: 6,
    name: "Ever Melisandre",
    email: "evermelisandre@gmail.com",
    age: 150,
    phone: "(232)545-6483",
    access: "manager",
  },
  {
    id: 7,
    name: "Ferrara Clifford",
    email: "ferraraclifford@gmail.com",
    age: 44,
    phone: "(543)124-0123",
    access: "user",
  },
  {
    id: 8,
    name: "Rossini Frances",
    email: "rossinifrances@gmail.com",
    age: 36,
    phone: "(222)444-5555",
    access: "user",
  },
  {
    id: 9,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    age: 65,
    phone: "(444)555-6239",
    access: "admin",
  },
];

export const mockDataTruck = [
    {
      id:1,
      "Vehicle Type": "Van",
      "Maximum Load Capacity (kg)": 1000,
      "Dimensions (L x W x H)": "3.5m x 1.8m x 1.9m",
      "Refrigeration": "Optional",
      "Special Features": ["GPS tracking", "Rear camera"]
    },
    {
      id:2,
      "Vehicle Type": "Box Truck",
      "Maximum Load Capacity (kg)": 3000,
      "Dimensions (L x W x H)": "6.0m x 2.5m x 2.4m",
      "Refrigeration": "Available",
      "Special Features": ["Tail lift", "Temperature control"]
    },
    {
      id:3,
      "Vehicle Type": "Flatbed",
      "Maximum Load Capacity (kg)": 5000,
      "Dimensions (L x W x H)": "7.2m x 2.6m",
      "Refrigeration": "Not available",
      "Special Features": ["Tie-down points", "Side rails"]
    },
    {
      id:4,
      "Vehicle Type": "Reefer Truck",
      "Maximum Load Capacity (kg)": 2500,
      "Dimensions (L x W x H)": "5.5m x 2.4m x 2.2m",
      "Refrigeration": "Standard",
      "Special Features": ["Temperature logging", "Dual compartment"]
    },
    {
      id:5,
      "Vehicle Type": "Pickup",
      "Maximum Load Capacity (kg)": 800,
      "Dimensions (L x W x H)": "2.5m x 1.5m x 1.2m",
      "Refrigeration": "Not available",
      "Special Features": ["4-wheel drive", "Extended cab"]
    },
    {
      id:6,
      "Vehicle Type": "Van",
      "Maximum Load Capacity (kg)": 1000,
      "Dimensions (L x W x H)": "3.5m x 1.8m x 1.9m",
      "Refrigeration": "Optional",
      "Special Features": ["GPS tracking", "Rear camera"]
    },
    {
      id:7,
      "Vehicle Type": "Box Truck",
      "Maximum Load Capacity (kg)": 3000,
      "Dimensions (L x W x H)": "6.0m x 2.5m x 2.4m",
      "Refrigeration": "Available",
      "Special Features": ["Tail lift", "Temperature control"]
    },
    {
      id:8,
      "Vehicle Type": "Flatbed",
      "Maximum Load Capacity (kg)": 5000,
      "Dimensions (L x W x H)": "7.2m x 2.6m",
      "Refrigeration": "Not available",
      "Special Features": ["Tie-down points", "Side rails"]
    },
    {
      id:9,
      "Vehicle Type": "Reefer Truck",
      "Maximum Load Capacity (kg)": 2500,
      "Dimensions (L x W x H)": "5.5m x 2.4m x 2.2m",
      "Refrigeration": "Standard",
      "Special Features": ["Temperature logging", "Dual compartment"]
    },
    {
      id:10,
      "Vehicle Type": "Pickup",
      "Maximum Load Capacity (kg)": 800,
      "Dimensions (L x W x H)": "2.5m x 1.5m x 1.2m",
      "Refrigeration": "Not available",
      "Special Features": ["4-wheel drive", "Extended cab"]
    },
    {
      id:11,
      "Vehicle Type": "Van",
      "Maximum Load Capacity (kg)": 1000,
      "Dimensions (L x W x H)": "3.5m x 1.8m x 1.9m",
      "Refrigeration": "Optional",
      "Special Features": ["GPS tracking", "Rear camera"]
    },
    {
      id:12,
      "Vehicle Type": "Box Truck",
      "Maximum Load Capacity (kg)": 3000,
      "Dimensions (L x W x H)": "6.0m x 2.5m x 2.4m",
      "Refrigeration": "Available",
      "Special Features": ["Tail lift", "Temperature control"]
    },
    {
      id:13,
      "Vehicle Type": "Flatbed",
      "Maximum Load Capacity (kg)": 5000,
      "Dimensions (L x W x H)": "7.2m x 2.6m",
      "Refrigeration": "Not available",
      "Special Features": ["Tie-down points", "Side rails"]
    },
    {
      id:14,
      "Vehicle Type": "Reefer Truck",
      "Maximum Load Capacity (kg)": 2500,
      "Dimensions (L x W x H)": "5.5m x 2.4m x 2.2m",
      "Refrigeration": "Standard",
      "Special Features": ["Temperature logging", "Dual compartment"]
    },
    {
      id:15,
      "Vehicle Type": "Pickup",
      "Maximum Load Capacity (kg)": 800,
      "Dimensions (L x W x H)": "2.5m x 1.5m x 1.2m",
      "Refrigeration": "Not available",
      "Special Features": ["4-wheel drive", "Extended cab"]
    },
  ];
  



export const mockDataContacts = [
  {
    id: 1,
    name: "Jon Snow",
    email: "jonsnow@gmail.com",
    age: 35,
    phone: "(665)121-5454",
    address: "0912 Won Street, Alabama, SY 10001",
    city: "New York",
    zipCode: "10001",
    registrarId: 123512,
  },
  {
    id: 2,
    name: "Cersei Lannister",
    email: "cerseilannister@gmail.com",
    age: 42,
    phone: "(421)314-2288",
    address: "1234 Main Street, New York, NY 10001",
    city: "New York",
    zipCode: "13151",
    registrarId: 123512,
  },
  {
    id: 3,
    name: "Jaime Lannister",
    email: "jaimelannister@gmail.com",
    age: 45,
    phone: "(422)982-6739",
    address: "3333 Want Blvd, Estanza, NAY 42125",
    city: "New York",
    zipCode: "87281",
    registrarId: 4132513,
  },
  {
    id: 4,
    name: "Anya Stark",
    email: "anyastark@gmail.com",
    age: 16,
    phone: "(921)425-6742",
    address: "1514 Main Street, New York, NY 22298",
    city: "New York",
    zipCode: "15551",
    registrarId: 123512,
  },
  {
    id: 5,
    name: "Daenerys Targaryen",
    email: "daenerystargaryen@gmail.com",
    age: 31,
    phone: "(421)445-1189",
    address: "11122 Welping Ave, Tenting, CD 21321",
    city: "Tenting",
    zipCode: "14215",
    registrarId: 123512,
  },
  {
    id: 6,
    name: "Ever Melisandre",
    email: "evermelisandre@gmail.com",
    age: 150,
    phone: "(232)545-6483",
    address: "1234 Canvile Street, Esvazark, NY 10001",
    city: "Esvazark",
    zipCode: "10001",
    registrarId: 123512,
  },
  {
    id: 7,
    name: "Ferrara Clifford",
    email: "ferraraclifford@gmail.com",
    age: 44,
    phone: "(543)124-0123",
    address: "22215 Super Street, Everting, ZO 515234",
    city: "Evertin",
    zipCode: "51523",
    registrarId: 123512,
  },
  {
    id: 8,
    name: "Rossini Frances",
    email: "rossinifrances@gmail.com",
    age: 36,
    phone: "(222)444-5555",
    address: "4123 Ever Blvd, Wentington, AD 142213",
    city: "Esteras",
    zipCode: "44215",
    registrarId: 512315,
  },
  {
    id: 9,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    age: 65,
    phone: "(444)555-6239",
    address: "51234 Avery Street, Cantory, ND 212412",
    city: "Colunza",
    zipCode: "111234",
    registrarId: 928397,
  },
  {
    id: 10,
    name: "Enteri Redack",
    email: "enteriredack@gmail.com",
    age: 42,
    phone: "(222)444-5555",
    address: "4123 Easer Blvd, Wentington, AD 142213",
    city: "Esteras",
    zipCode: "44215",
    registrarId: 533215,
  },
  {
    id: 11,
    name: "Steve Goodman",
    email: "stevegoodmane@gmail.com",
    age: 11,
    phone: "(444)555-6239",
    address: "51234 Fiveton Street, CunFory, ND 212412",
    city: "Colunza",
    zipCode: "1234",
    registrarId: 92197,
  },
];

export const mockDataTime = 
[
  {
    id: 1,
    "Distribution Center ID": "DC975",
    "Working Hours": "8:00 AM - 6:00 PM"
  },
  {
    id: 2,
    "Distribution Center ID": "DC246",
    "Working Hours": "7:30 AM - 5:30 PM"
  },
  {
    id: 3,
    "Distribution Center ID": "DC503",
    "Working Hours": "9:00 AM - 7:00 PM"
  },
  {
    id: 4,
    "Distribution Center ID": "DC789",
    "Working Hours": "8:30 AM - 6:30 PM"
  },
  {
    id: 5,
    "Distribution Center ID": "DC362",
    "Working Hours": "8:00 AM - 6:00 PM"
  },
  {
    id: 6,
    "Distribution Center ID": "DC815",
    "Working Hours": "7:00 AM - 5:00 PM"
  },
  {
    id: 7,
    "Distribution Center ID": "DC124",
    "Working Hours": "9:00 AM - 6:00 PM"
  },
  {
    id: 8,
    "Distribution Center ID": "DC672",
    "Working Hours": "8:30 AM - 5:30 PM"
  },
  {
    id: 9,
    "Distribution Center ID": "DC529",
    "Working Hours": "7:00 AM - 4:30 PM"
  },
  {
    id: 10,
    "Distribution Center ID": "DC937",
    "Working Hours": "8:00 AM - 5:00 PM"
  }
];

export const mockDataLocnGeo = 
[
  {
    "id": 1,
    "coordinates": [40.7128, -74.0060],
    "streetName": "Broadway Ave",
    "distance": 3,
    "speedLimit": 30,
    "geographicalConstraints": "tollBridge George Washington Bridge"
  },
  {
    "id": 2,
    "coordinates": [34.0522, -118.2437],
    "streetName": "Santa Monica Blvd",
    "distance": 2.5,
    "speedLimit": 25,
    "geographicalConstraints": "noThroughTrucks Downtown LA"
  },
  {
    "id": 3,
    "coordinates": [41.8781, -87.6298],
    "streetName": "Michigan Ave",
    "distance": 1.5,
    "speedLimit": 20,
    "geographicalConstraints": "lowEmissionZone Chicago Loop"
  },
  {
    "id": 4,
    "coordinates": [39.9526, -75.1652],
    "streetName": "Market Street",
    "distance": 1,
    "speedLimit": 15,
    "geographicalConstraints": "pedestrianZone Center City, Philly"
  },
  {
    "id": 5,
    "coordinates": [29.7604, -95.3698],
    "streetName": "Main Street",
    "distance": 2,
    "speedLimit": 30,
    "geographicalConstraints": "noParking Downtown Houston"
  },
  {
    "id": 6,
    "coordinates": [32.7157, -117.1611],
    "streetName": "Harbor Drive",
    "distance": 3.5,
    "speedLimit": 35,
    "geographicalConstraints": "roadClosure Construction on I-5"
  },
  {
    "id": 7,
    "coordinates": [37.7749, -122.4194],
    "streetName": "Market Street",
    "distance": 2,
    "speedLimit": 25,
    "geographicalConstraints": "tunnelRestrictions Bay Area Bridges"
  },
  {
    "id": 8,
    "coordinates": [47.6062, -122.3321],
    "streetName": "Pine Street",
    "distance": 1.8,
    "speedLimit": 20,
    "geographicalConstraints": "weightLimit Seattle Waterfront"
  },
  {
    "id": 9,
    "coordinates": [33.7490, -84.3880],
    "streetName": "Peachtree Street",
    "distance": 2.2,
    "speedLimit": 25,
    "geographicalConstraints": "heightRestriction Underpass on I-85"
  },
  {
    "id": 10,
    "coordinates": [38.9072, -77.0369],
    "streetName": "Pennsylvania Ave",
    "distance": 1.7,
    "speedLimit": 30,
    "geographicalConstraints": "speedLimitReduction National Mall"
  }
];


export const mockDataTrafficnWeather = [
  {
    id:1,
    roadSegment: "I-95 North",
    trafficStatus: "Heavy congestion",
    weatherCondition: "Partly cloudy"
  },
  {
    id:2,
    roadSegment: "Route 66",
    trafficStatus: "Moderate traffic",
    weatherCondition: "Clear skies"
  },
  {
    id:3,
    roadSegment: "Highway 101",
    trafficStatus: "Smooth traffic flow",
    weatherCondition: "Rain showers"
  },
  {
    id:4,
    roadSegment: "Interstate 5",
    trafficStatus: "Accident, lane closure",
    weatherCondition: "Foggy"
  },
  {
    id:5,
    roadSegment: "I-80 West",
    trafficStatus: "Construction zone, delays expected",
    weatherCondition: "Sunny"
  },
  {
    id:6,
    roadSegment: "US-1 Coastal Highway",
    trafficStatus: "Light traffic",
    weatherCondition: "Windy"
  },
  {
    id:7,
    roadSegment: "I-70 East",
    trafficStatus: "Vehicle breakdown, shoulder blocked",
    weatherCondition: "Thunderstorms"
  },
  {
    id:8,
    roadSegment: "State Route 99",
    trafficStatus: "Road closed due to flooding",
    weatherCondition: "Heavy rain"
  },
  {
    id:9,
    roadSegment: "I-10 South",
    trafficStatus: "Normal traffic",
    weatherCondition: "Scattered clouds"
  },
  {
    id:10,
    roadSegment: "Interstate 495",
    trafficStatus: "Delays due to road maintenance",
    weatherCondition: "Snow showers"
  },
  {
    id:11,
    roadSegment: "Highway 280",
    trafficStatus: "Minor delays",
    weatherCondition: "Partly cloudy"
  },
  {
    id:12,
    roadSegment: "Interstate 90",
    trafficStatus: "Heavy rain causing flooding",
    weatherCondition: "Heavy rain"
  },
  {
    id:13,
    roadSegment: "US-50",
    trafficStatus: "Congestion due to roadworks",
    weatherCondition: "Clear skies"
  },
  {
    id:14,
    roadSegment: "State Route 1A",
    trafficStatus: "Accident cleared, residual delays",
    weatherCondition: "Sunny"
  },
  {
    id:15,
    roadSegment: "I-20",
    trafficStatus: "Free flowing traffic",
    weatherCondition: "Scattered clouds"
  },
  {
    id:16,
    roadSegment: "Interstate 495",
    trafficStatus: "Road closed for maintenance",
    weatherCondition: "Foggy"
  },
  {
    id:17,
    roadSegment: "Highway 101",
    trafficStatus: "Moderate traffic",
    weatherCondition: "Light rain"
  },
  {
    id:18,
    roadSegment: "Route 22",
    trafficStatus: "Vehicle fire, expect delays",
    weatherCondition: "Windy"
  },
  {
    id:19,
    roadSegment: "I-5 North",
    trafficStatus: "Roadwork, reduced speed limit",
    weatherCondition: "Overcast"
  },
  {
    id:20,
    roadSegment: "US-101",
    trafficStatus: "Major accident, road closure",
    weatherCondition: "Thunderstorms"
  }
];

export const mockDataAlgorithm = 
[
  {
    id:1,
    "Algorithm": "Mixed Integer Linear Programming",
    "Computation Time": "Medium",
    "Accuracy": "High",
    "Scalibility": "Medium",
    "Idea for": "Linear objective function\nMedium no. of variables\nLow no. of constraints"
  },
  {
    id:2,
    "Algorithm": "Non Linear Programming",
    "Computation Time": "High",
    "Accuracy": "High",
    "Scalibility": "Low",
    "Idea for": "Linear/Non-Linear objective function\nMedium no. of variables\nLow no. of constraints"
  },
  {
    id:3,
    "Algorithm": "Genetic Algorithm",
    "Computation Time": "High",
    "Accuracy": "Medium",
    "Scalibility": "Low",
    "Idea for": "Linear/Non-Linear objective function\nLow no. of variables\nMedium no. of constraints"
  },
  {
    id:4,
    "Algorithm": "Particle Swarm Optimization",
    "Computation Time": "High",
    "Accuracy": "Medium",
    "Scalibility": "Low",
    "Idea for": "Linear/Non-Linear objective function\nLow no. of variables\nMedium no. of constraints"
  },
  {
    id:5,
    "Algorithm": "Step Optimization",
    "Computation Time": "Medium",
    "Accuracy": "Medium",
    "Scalibility": "Medium",
    "Idea for": "Linear/Non-Linear objective function\nMedium no. of variables\nMedium no. of constraints"
  },
  {
    id:6,
    "Algorithm": "Custom Heuristic",
    "Computation Time": "Low",
    "Accuracy": "Medium",
    "Scalibility": "Medium",
    "Idea for": "Linear/Non-Linear objective function\nHigh no. of variables\nHigh no. of constraints"
  }
];


export const mockDataTechnician = 
[
  {
    id:1,
      "TechnicianID": "A1",
      "Rating(/10)": 8,
      "Expertise(ProductCategories)": "A,B,C,D",
      "Charge($/hr)": 25
  },
  {
    id:2,
      "TechnicianID": "A2",
      "Rating(/10)": 7,
      "Expertise(ProductCategories)": "B,D",
      "Charge($/hr)": 28
  },
  {
    id:3,
      "TechnicianID": "A3",
      "Rating(/10)": 9,
      "Expertise(ProductCategories)": "B,D,E",
      "Charge($/hr)": 30
  },
  {
    id:4,
      "TechnicianID": "A4",
      "Rating(/10)": 7,
      "Expertise(ProductCategories)": "A,E",
      "Charge($/hr)": 24
  },
  {
    id:5,
      "TechnicianID": "A5",
      "Rating(/10)": 9,
      "Expertise(ProductCategories)": "B,C,D,E",
      "Charge($/hr)": 25
  },
  {
    id:6,
      "TechnicianID": "A6",
      "Rating(/10)": 8,
      "Expertise(ProductCategories)": "A,C,D,E",
      "Charge($/hr)": 26
  },
  {
    id:7,
      "TechnicianID": "A7",
      "Rating(/10)": 9,
      "Expertise(ProductCategories)": "C,D,E",
      "Charge($/hr)": 28
  },
  {
    id:8,
      "TechnicianID": "A8",
      "Rating(/10)": 8,
      "Expertise(ProductCategories)": "A,B,C,",
      "Charge($/hr)": 30
  },
  {
    id:9,
      "TechnicianID": "A9",
      "Rating(/10)": 8,
      "Expertise(ProductCategories)": "A,B,C,D,E",
      "Charge($/hr)": 25
  },
  {
    id:10,
      "TechnicianID": "A10",
      "Rating(/10)": 10,
      "Expertise(ProductCategories)": "B,C,E",
      "Charge($/hr)": 28
  },
  {
    id:11,
      "TechnicianID": "A11",
      "Rating(/10)": 7,
      "Expertise(ProductCategories)": "A,B",
      "Charge($/hr)": 30
  },
  {
    id:12,
      "TechnicianID": "A12",
      "Rating(/10)": 8,
      "Expertise(ProductCategories)": "B,C,D,E",
      "Charge($/hr)": 25
  },
  {
    id:13,
      "TechnicianID": "A13",
      "Rating(/10)": 7,
      "Expertise(ProductCategories)": "A,C,E",
      "Charge($/hr)": 26
  },
  {
    id:14,
      "TechnicianID": "A14",
      "Rating(/10)": 9,
      "Expertise(ProductCategories)": "C,E",
      "Charge($/hr)": 28
  },
  {
    id:15,
      "TechnicianID": "A15",
      "Rating(/10)": 8,
      "Expertise(ProductCategories)": "A,B,C,D,E",
      "Charge($/hr)": 24
  },
  {
    id:16,
      "TechnicianID": "A16",
      "Rating(/10)": 7,
      "Expertise(ProductCategories)": "A,B,C",
      "Charge($/hr)": 25
  },
  {
    id:17,
      "TechnicianID": "A17",
      "Rating(/10)": 8,
      "Expertise(ProductCategories)": "C,D,E",
      "Charge($/hr)": 26
  },
  {
    id:18,
      "TechnicianID": "A18",
      "Rating(/10)": 9,
      "Expertise(ProductCategories)": "A,B,C",
      "Charge($/hr)": 28
  },
  {
    id:19,
      "TechnicianID": "A19",
      "Rating(/10)": 10,
      "Expertise(ProductCategories)": "B,C,D",
      "Charge($/hr)": 25
  },
  {
    id:20,
      "TechnicianID": "A20",
      "Rating(/10)": 8,
      "Expertise(ProductCategories)": "A,B,C",
      "Charge($/hr)": 26
  }
];

export const mockDataDemandData = 
[
  {
    id:1,
      "Type": "Service",
      "Citycode": "C1",
      "ProductCategory": "A",
      "Pincode": 13226,
      "Availabletime": "10AM-5PM"
  },
  {
    id:2,
      "Type": "Delivery",
      "Citycode": "C3",
      "ProductCategory": "A",
      "Pincode": 12990,
      "Availabletime": "2PM-6PM"
  },
  {
    id:3,
      "Type": "Delivery",
      "Citycode": "C1",
      "ProductCategory": "B",
      "Pincode": 12592,
      "Availabletime": "3PM-6PM"
  },
  {
    id:4,
      "Type": "Delivery",
      "Citycode": "C2",
      "ProductCategory": "C",
      "Pincode": 13031,
      "Availabletime": "9AM-7PM"
  },
  {
    id:5,
      "Type": "Service",
      "Citycode": "C3",
      "ProductCategory": "C",
      "Pincode": 13143,
      "Availabletime": "11AM-4PM"
  },
  {
    id:6,
      "Type": "Delivery",
      "Citycode": "C4",
      "ProductCategory": "D",
      "Pincode": 12624,
      "Availabletime": "4PM-8PM"
  },
  {
    id:7,
      "Type": "Service",
      "Citycode": "C5",
      "ProductCategory": "E",
      "Pincode": 13201,
      "Availabletime": "1PM-7PM"
  },
  {
    id:8,
      "Type": "Delivery",
      "Citycode": "C1",
      "ProductCategory": "A",
      "Pincode": 12924,
      "Availabletime": "10AM-7PM"
  },
  {
    id:9,
      "Type": "Delivery",
      "Citycode": "C5",
      "ProductCategory": "B",
      "Pincode": 13017,
      "Availabletime": "11AM-5PM"
  },
  {
    id:10,
      "Type": "Delivery",
      "Citycode": "C4",
      "ProductCategory": "C",
      "Pincode": 13155,
      "Availabletime": "2PM-7PM"
  },
  {
    id:11,
      "Type": "Delivery",
      "Citycode": "C3",
      "ProductCategory": "D",
      "Pincode": 12469,
      "Availabletime": "3PM-7PM"
  },
  {
    id:12,
      "Type": "Service",
      "Citycode": "C2",
      "ProductCategory": "E",
      "Pincode": 12552,
      "Availabletime": "10AM-6PM"
  },
  {
    id:13,
      "Type": "Delivery",
      "Citycode": "C5",
      "ProductCategory": "A",
      "Pincode": 12598,
      "Availabletime": "9AM-8PM"
  },
  {
    id:14,
      "Type": "Delivery",
      "Citycode": "C4",
      "ProductCategory": "B",
      "Pincode": 12691,
      "Availabletime": "2PM-5PM"
  },
  {
    id:15,
      "Type": "Service",
      "Citycode": "C3",
      "ProductCategory": "B",
      "Pincode": 12555,
      "Availabletime": "1PM-7PM"
  },
  {
    id:16,
      "Type": "Delivery",
      "Citycode": "C2",
      "ProductCategory": "C",
      "Pincode": 13205,
      "Availabletime": "10AM-2PM"
  },
  {
    id:17,
      "Type": "Delivery",
      "Citycode": "C1",
      "ProductCategory": "A",
      "Pincode": 13057,
      "Availabletime": "10AM-6PM"
  },
  {
    id:18,
      "Type": "Service",
      "Citycode": "C5",
      "ProductCategory": "A",
      "Pincode": 12371,
      "Availabletime": "11AM-4PM"
  },
  {
    id:19,
      "Type": "Delivery",
      "Citycode": "C4",
      "ProductCategory": "E",
      "Pincode": 12454,
      "Availabletime": "10AM-4PM"
  }
];


export const mockDataCostnPerformanceMetrics = 
[
  {
    "id": 1,
    "vehicleId": 101,
    "fuelCost": 3.50,
    "laborCost": 20.00
  },
  {
    "id": 2,
    "vehicleId": 102,
    "fuelCost": 3.75,
    "laborCost": 22.50
  },
  {
    "id": 3,
    "vehicleId": 103,
    "fuelCost": 3.60,
    "laborCost": 21.00
  },
  {
    "id": 4,
    "vehicleId": 104,
    "fuelCost": 3.65,
    "laborCost": 21.50
  },
  {
    "id": 5,
    "vehicleId": 105,
    "fuelCost": 3.55,
    "laborCost": 20.50
  },
  {
    "id": 6,
    "vehicleId": 106,
    "fuelCost": 3.70,
    "laborCost": 22.00
  },
  {
    "id": 7,
    "vehicleId": 107,
    "fuelCost": 3.45,
    "laborCost": 19.50
  },
  {
    "id": 8,
    "vehicleId": 108,
    "fuelCost": 3.80,
    "laborCost": 23.00
  },
  {
    "id": 9,
    "vehicleId": 109,
    "fuelCost": 3.75,
    "laborCost": 22.50
  },
  {
    "id": 10,
    "vehicleId": 110,
    "fuelCost": 3.85,
    "laborCost": 24.00
  },
  {
    "id": 11,
    "vehicleId": 111,
    "fuelCost": 3.40,
    "laborCost": 19.00
  },
  {
    "id": 12,
    "vehicleId": 112,
    "fuelCost": 3.90,
    "laborCost": 25.00
  },
  {
    "id": 13,
    "vehicleId": 113,
    "fuelCost": 3.95,
    "laborCost": 26.00
  },
  {
    "id": 14,
    "vehicleId": 114,
    "fuelCost": 3.50,
    "laborCost": 20.00
  },
  {
    "id": 15,
    "vehicleId": 115,
    "fuelCost": 3.55,
    "laborCost": 20.50
  },
  {
    "id": 16,
    "vehicleId": 116,
    "fuelCost": 3.60,
    "laborCost": 21.00
  },
  {
    "id": 17,
    "vehicleId": 117,
    "fuelCost": 3.65,
    "laborCost": 21.50
  },
  {
    "id": 18,
    "vehicleId": 118,
    "fuelCost": 3.70,
    "laborCost": 22.00
  },
  {
    "id": 19,
    "vehicleId": 119,
    "fuelCost": 3.75,
    "laborCost": 22.50
  },
  {
    "id": 20,
    "vehicleId": 120,
    "fuelCost": 3.80,
    "laborCost": 23.00
  }
];



export const mockDataRegulationsOperationLimits = 
[
  {
    "id": 1,
    "driverId": 12345,
    "maxHoursOfService": 14,
    "vehicleId": 101,
    "maxDistance": 500,
    "maxTime": 10
  },
  {
    "id": 2,
    "driverId": 23456,
    "maxHoursOfService": 13,
    "vehicleId": 102,
    "maxDistance": 450,
    "maxTime": 9
  },
  {
    "id": 3,
    "driverId": 34567,
    "maxHoursOfService": 12,
    "vehicleId": 103,
    "maxDistance": 400,
    "maxTime": 8
  },
  {
    "id": 4,
    "driverId": 45678,
    "maxHoursOfService": 11,
    "vehicleId": 104,
    "maxDistance": 350,
    "maxTime": 7
  },
  {
    "id": 5,
    "driverId": 56789,
    "maxHoursOfService": 10,
    "vehicleId": 105,
    "maxDistance": 300,
    "maxTime": 6
  },
  {
    "id": 6,
    "driverId": 67890,
    "maxHoursOfService": 9,
    "vehicleId": 106,
    "maxDistance": 250,
    "maxTime": 5
  },
  {
    "id": 7,
    "driverId": 78901,
    "maxHoursOfService": 8,
    "vehicleId": 107,
    "maxDistance": 200,
    "maxTime": 4
  },
  {
    "id": 8,
    "driverId": 89012,
    "maxHoursOfService": 7,
    "vehicleId": 108,
    "maxDistance": 150,
    "maxTime": 3
  },
  {
    "id": 9,
    "driverId": 90123,
    "maxHoursOfService": 6,
    "vehicleId": 109,
    "maxDistance": 100,
    "maxTime": 2
  },
  {
    "id": 10,
    "driverId": 10123,
    "maxHoursOfService": 5,
    "vehicleId": 110,
    "maxDistance": 50,
    "maxTime": 1
  },
  {
    "id": 11,
    "driverId": 11234,
    "maxHoursOfService": 14,
    "vehicleId": 111,
    "maxDistance": 500,
    "maxTime": 10
  },
  {
    "id": 12,
    "driverId": 12345,
    "maxHoursOfService": 13,
    "vehicleId": 112,
    "maxDistance": 450,
    "maxTime": 9
  },
  {
    "id": 13,
    "driverId": 23456,
    "maxHoursOfService": 12,
    "vehicleId": 113,
    "maxDistance": 400,
    "maxTime": 8
  },
  {
    "id": 14,
    "driverId": 34567,
    "maxHoursOfService": 11,
    "vehicleId": 114,
    "maxDistance": 350,
    "maxTime": 7
  },
  {
    "id": 15,
    "driverId": 45678,
    "maxHoursOfService": 10,
    "vehicleId": 115,
    "maxDistance": 300,
    "maxTime": 6
  },
  {
    "id": 16,
    "driverId": 56789,
    "maxHoursOfService": 9,
    "vehicleId": 116,
    "maxDistance": 250,
    "maxTime": 5
  },
  {
    "id": 17,
    "driverId": 67890,
    "maxHoursOfService": 8,
    "vehicleId": 117,
    "maxDistance": 200,
    "maxTime": 4
  },
  {
    "id": 18,
    "driverId": 78901,
    "maxHoursOfService": 7,
    "vehicleId": 118,
    "maxDistance": 150,
    "maxTime": 3
  },
  {
    "id": 19,
    "driverId": 89012,
    "maxHoursOfService": 6,
    "vehicleId": 119,
    "maxDistance": 100,
    "maxTime": 2
  },
  {
    "id": 20,
    "driverId": 90123,
    "maxHoursOfService": 5,
    "vehicleId": 120,
    "maxDistance": 50,
    "maxTime": 1
  }
];


export const mockDataCustomernOrder = 
[
  {
    id: 1,
    customerId: 101,
    weight: 500,
    volume: 10,
    startTime: '09:00 AM',
    endTime: '12:00 PM',
    priority: 'High'
  },
  {
    id: 2,
    customerId: 102,
    weight: 300,
    volume: 5,
    startTime: '11:00 AM',
    endTime: '02:00 PM',
    priority: 'Medium'
  },
  {
    id: 3,
    customerId: 103,
    weight: 700,
    volume: 12,
    startTime: '10:00 AM',
    endTime: '01:00 PM',
    priority: 'High'
  },
  {
    id: 4,
    customerId: 104,
    weight: 400,
    volume: 8,
    startTime: '01:00 PM',
    endTime: '04:00 PM',
    priority: 'Low'
  },
  {
    id: 5,
    customerId: 105,
    weight: 600,
    volume: 15,
    startTime: '08:00 AM',
    endTime: '11:00 AM',
    priority: 'High'
  },
  {
    id: 6,
    customerId: 106,
    weight: 200,
    volume: 4,
    startTime: '12:00 PM',
    endTime: '03:00 PM',
    priority: 'Medium'
  },
  {
    id: 7,
    customerId: 107,
    weight: 350,
    volume: 7,
    startTime: '02:00 PM',
    endTime: '05:00 PM',
    priority: 'Low'
  },
  {
    id: 8,
    customerId: 108,
    weight: 450,
    volume: 9,
    startTime: '10:00 AM',
    endTime: '01:00 PM',
    priority: 'Medium'
  },
  {
    id: 9,
    customerId: 109,
    weight: 550,
    volume: 11,
    startTime: '11:00 AM',
    endTime: '02:00 PM',
    priority: 'High'
  },
  {
    id: 10,
    customerId: 110,
    weight: 250,
    volume: 5,
    startTime: '03:00 PM',
    endTime: '06:00 PM',
    priority: 'Low'
  }
];



export const mockDataGeoCons =
[
  {
    id:1,
    "Distribution Center Unique ID": "DC975",
    "Location (City)": "Los Angeles",
    "List of Pincodes Served": ["90001", "90002", "90003", "90004", "90005", "90006", "90007", "90008", "90009", "90010", "90011", "90012", "90013", "90014", "90015"]
  },
  {
    id:2,
    "Distribution Center Unique ID": "DC246",
    "Location (City)": "Chicago",
    "List of Pincodes Served": ["60601", "60602", "60603", "60604", "60605", "60606", "60607", "60608", "60609", "60610", "60611", "60612", "60613", "60614", "60615"]
  },
  {
    id:3,
    "Distribution Center Unique ID": "DC503",
    "Location (City)": "Dallas",
    "List of Pincodes Served": ["75201", "75202", "75203", "75204", "75205", "75206", "75207", "75208", "75209", "75210", "75211", "75212", "75213", "75214", "75215"]
  },
  {
    id:4,
    "Distribution Center Unique ID": "DC789",
    "Location (City)": "Atlanta",
    "List of Pincodes Served": ["30301", "30302", "30303", "30304", "30305", "30306", "30307", "30308", "30309", "30310", "30311", "30312", "30313", "30314", "30315"]
  },
  {
    id:5,
    "Distribution Center Unique ID": "DC362",
    "Location (City)": "New York",
    "List of Pincodes Served": ["10001", "10002", "10003", "10004", "10005", "10006", "10007", "10008", "10009", "10010", "10011", "10012", "10013", "10014", "10015"]
  },
  {
    id:6,
    "Distribution Center Unique ID": "DC815",
    "Location (City)": "Houston",
    "List of Pincodes Served": ["77001", "77002", "77003", "77004", "77005", "77006", "77007", "77008", "77009", "77010", "77011", "77012", "77013", "77014", "77015"]
  },
  {
    id:7,
    "Distribution Center Unique ID": "DC124",
    "Location (City)": "Miami",
    "List of Pincodes Served": ["33101", "33102", "33103", "33104", "33105", "33106", "33107", "33108", "33109", "33110", "33111", "33112", "33113", "33114", "33115"]
  },
  {
    id:8,
    "Distribution Center Unique ID": "DC672",
    "Location (City)": "Seattle",
    "List of Pincodes Served": ["98101", "98102", "98103", "98104", "98105", "98106", "98107", "98108", "98109", "98110", "98111", "98112", "98113", "98114", "98115"]
  },
  {
    id:9,
    "Distribution Center Unique ID": "DC529",
    "Location (City)": "Philadelphia",
    "List of Pincodes Served": ["19101", "19102", "19103", "19104", "19105", "19106", "19107", "19108", "19109", "19110", "19111", "19112", "19113", "19114", "19115"]
  },
  {
    id:10,
    "Distribution Center Unique ID": "DC937",
    "Location (City)": "Phoenix",
    "List of Pincodes Served": ["85001", "85002", "85003", "85004", "85005", "85006", "85007", "85008", "85009", "85010", "85011", "85012", "85013", "85014", "85015"]
  },
  {
    id:11,
    "Distribution Center Unique ID": "DC362",
    "Location (City)": "New York",
    "List of Pincodes Served": ["10001", "10002", "10003", "10004", "10005", "10006", "10007", "10008", "10009", "10010", "10011", "10012", "10013", "10014", "10015"]
  },
  {
    id:12,
    "Distribution Center Unique ID": "DC815",
    "Location (City)": "Houston",
    "List of Pincodes Served": ["77001", "77002", "77003", "77004", "77005", "77006", "77007", "77008", "77009", "77010", "77011", "77012", "77013", "77014", "77015"]
  },
  {
    id:13,
    "Distribution Center Unique ID": "DC124",
    "Location (City)": "Miami",
    "List of Pincodes Served": ["33101", "33102", "33103", "33104", "33105", "33106", "33107", "33108", "33109", "33110", "33111", "33112", "33113", "33114", "33115"]
  },
  {
    id:14,
    "Distribution Center Unique ID": "DC672",
    "Location (City)": "Seattle",
    "List of Pincodes Served": ["98101", "98102", "98103", "98104", "98105", "98106", "98107", "98108", "98109", "98110", "98111", "98112", "98113", "98114", "98115"]
  },
  {
    id:15,
    "Distribution Center Unique ID": "DC529",
    "Location (City)": "Philadelphia",
    "List of Pincodes Served": ["19101", "19102", "19103", "19104", "19105", "19106", "19107", "19108", "19109", "19110", "19111", "19112", "19113", "19114", "19115"]
  },
  {
    id:16,
    "Distribution Center Unique ID": "DC937",
    "Location (City)": "Phoenix",
    "List of Pincodes Served": ["85001", "85002", "85003", "85004", "85005", "85006", "85007", "85008", "85009", "85010", "85011", "85012", "85013", "85014", "85015"]
  }
];


export const mockDataInvoices = [
  {
    id: 1,
    name: "Jon Snow",
    email: "jonsnow@gmail.com",
    cost: "21.24",
    phone: "(665)121-5454",
    date: "03/12/2022",
  },
  {
    id: 2,
    name: "Cersei Lannister",
    email: "cerseilannister@gmail.com",
    cost: "1.24",
    phone: "(421)314-2288",
    date: "06/15/2021",
  },
  {
    id: 3,
    name: "Jaime Lannister",
    email: "jaimelannister@gmail.com",
    cost: "11.24",
    phone: "(422)982-6739",
    date: "05/02/2022",
  },
  {
    id: 4,
    name: "Anya Stark",
    email: "anyastark@gmail.com",
    cost: "80.55",
    phone: "(921)425-6742",
    date: "03/21/2022",
  },
  {
    id: 5,
    name: "Daenerys Targaryen",
    email: "daenerystargaryen@gmail.com",
    cost: "1.24",
    phone: "(421)445-1189",
    date: "01/12/2021",
  },
  {
    id: 6,
    name: "Ever Melisandre",
    email: "evermelisandre@gmail.com",
    cost: "63.12",
    phone: "(232)545-6483",
    date: "11/02/2022",
  },
  {
    id: 7,
    name: "Ferrara Clifford",
    email: "ferraraclifford@gmail.com",
    cost: "52.42",
    phone: "(543)124-0123",
    date: "02/11/2022",
  },
  {
    id: 8,
    name: "Rossini Frances",
    email: "rossinifrances@gmail.com",
    cost: "21.24",
    phone: "(222)444-5555",
    date: "05/02/2021",
  },
];

export const mockTransactions = [
  {
    txId: "01e4dsa",
    user: "johndoe",
    date: "2021-09-01",
    cost: "43.95",
  },
  {
    txId: "0315dsaa",
    user: "jackdower",
    date: "2022-04-01",
    cost: "133.45",
  },
  {
    txId: "01e4dsa",
    user: "aberdohnny",
    date: "2021-09-01",
    cost: "43.95",
  },
  {
    txId: "51034szv",
    user: "goodmanave",
    date: "2022-11-05",
    cost: "200.95",
  },
  {
    txId: "0a123sb",
    user: "stevebower",
    date: "2022-11-02",
    cost: "13.55",
  },
  {
    txId: "01e4dsa",
    user: "aberdohnny",
    date: "2021-09-01",
    cost: "43.95",
  },
  {
    txId: "120s51a",
    user: "wootzifer",
    date: "2019-04-15",
    cost: "24.20",
  },
  {
    txId: "0315dsaa",
    user: "jackdower",
    date: "2022-04-01",
    cost: "133.45",
  },
];

export const mockBarData = [
  {
    country: "AD",
    "hot dog": 137,
    "shot dogColor": "hsl(229, 70%, 50%)",
    burger: 96,
    burgerColor: "hsl(296, 70%, 50%)",
    kebab: 72,
    kebabColor: "hsl(97, 70%, 50%)",
    donut: 140,
    donutColor: "hsl(340, 70%, 50%)",
  },
  {
    country: "AE",
    "hot dog": 55,
    "hot dogColor": "hsl(307, 70%, 50%)",
    burger: 28,
    burgerColor: "hsl(111, 70%, 50%)",
    kebab: 58,
    kebabColor: "hsl(273, 70%, 50%)",
    donut: 29,
    donutColor: "hsl(275, 70%, 50%)",
  },
  {
    country: "AF",
    "hot dog": 109,
    "hot dogColor": "hsl(72, 70%, 50%)",
    burger: 23,
    burgerColor: "hsl(96, 70%, 50%)",
    kebab: 34,
    kebabColor: "hsl(106, 70%, 50%)",
    donut: 152,
    donutColor: "hsl(256, 70%, 50%)",
  },
  {
    country: "AG",
    "hot dog": 133,
    "hot dogColor": "hsl(257, 70%, 50%)",
    burger: 52,
    burgerColor: "hsl(326, 70%, 50%)",
    kebab: 43,
    kebabColor: "hsl(110, 70%, 50%)",
    donut: 83,
    donutColor: "hsl(9, 70%, 50%)",
  },
  {
    country: "AI",
    "hot dog": 81,
    "hot dogColor": "hsl(190, 70%, 50%)",
    burger: 80,
    burgerColor: "hsl(325, 70%, 50%)",
    kebab: 112,
    kebabColor: "hsl(54, 70%, 50%)",
    donut: 35,
    donutColor: "hsl(285, 70%, 50%)",
  },
  {
    country: "AL",
    "hot dog": 66,
    "hot dogColor": "hsl(208, 70%, 50%)",
    burger: 111,
    burgerColor: "hsl(334, 70%, 50%)",
    kebab: 167,
    kebabColor: "hsl(182, 70%, 50%)",
    donut: 18,
    donutColor: "hsl(76, 70%, 50%)",
  },
  {
    country: "AM",
    "hot dog": 80,
    "hot dogColor": "hsl(87, 70%, 50%)",
    burger: 47,
    burgerColor: "hsl(141, 70%, 50%)",
    kebab: 158,
    kebabColor: "hsl(224, 70%, 50%)",
    donut: 49,
    donutColor: "hsl(274, 70%, 50%)",
  },
];

export const mockPieData = [
  {
    id: "hack",
    label: "hack",
    value: 239,
    color: "hsl(104, 70%, 50%)",
  },
  {
    id: "make",
    label: "make",
    value: 170,
    color: "hsl(162, 70%, 50%)",
  },
  {
    id: "go",
    label: "go",
    value: 322,
    color: "hsl(291, 70%, 50%)",
  },
  {
    id: "lisp",
    label: "lisp",
    value: 503,
    color: "hsl(229, 70%, 50%)",
  },
  {
    id: "scala",
    label: "scala",
    value: 584,
    color: "hsl(344, 70%, 50%)",
  },
];

export const mockLineData1 = [
  {
    id: "japan",
    color: tokens("dark").greenAccent[500],
    data: [
      {
        x: "plane",
        y: 101,
      },
      {
        x: "helicopter",
        y: 75,
      },
      {
        x: "boat",
        y: 36,
      },
      {
        x: "train",
        y: 216,
      },
      {
        x: "subway",
        y: 35,
      },
      {
        x: "bus",
        y: 236,
      },
      {
        x: "car",
        y: 88,
      },
      {
        x: "moto",
        y: 232,
      },
      {
        x: "bicycle",
        y: 281,
      },
      {
        x: "horse",
        y: 1,
      },
      {
        x: "skateboard",
        y: 35,
      },
      {
        x: "others",
        y: 14,
      },
    ],
  },
  {
    id: "france",
    color: tokens("dark").blueAccent[300],
    data: [
      {
        x: "plane",
        y: 212,
      },
      {
        x: "helicopter",
        y: 190,
      },
      {
        x: "boat",
        y: 270,
      },
      {
        x: "train",
        y: 9,
      },
      {
        x: "subway",
        y: 75,
      },
      {
        x: "bus",
        y: 175,
      },
      {
        x: "car",
        y: 33,
      },
      {
        x: "moto",
        y: 189,
      },
      {
        x: "bicycle",
        y: 97,
      },
      {
        x: "horse",
        y: 87,
      },
      {
        x: "skateboard",
        y: 299,
      },
      {
        x: "others",
        y: 251,
      },
    ],
  },
  {
    id: "us",
    color: tokens("dark").redAccent[200],
    data: [
      {
        x: "plane",
        y: 191,
      },
      {
        x: "helicopter",
        y: 136,
      },
      {
        x: "boat",
        y: 91,
      },
      {
        x: "train",
        y: 190,
      },
      {
        x: "subway",
        y: 211,
      },
      {
        x: "bus",
        y: 152,
      },
      {
        x: "car",
        y: 189,
      },
      {
        x: "moto",
        y: 152,
      },
      {
        x: "bicycle",
        y: 8,
      },
      {
        x: "horse",
        y: 197,
      },
      {
        x: "skateboard",
        y: 107,
      },
      {
        x: "others",
        y: 170,
      },
    ],
  },
];



export const mockLineData2 = [
  {
    "id": "japan",
    color: tokens("dark").greenAccent[500],
    "data": [
      {
        "x": "plane",
        "y": 234
      },
      {
        "x": "helicopter",
        "y": 179
      },
      {
        "x": "boat",
        "y": 76
      },
      {
        "x": "train",
        "y": 212
      },
      {
        "x": "subway",
        "y": 63
      },
      {
        "x": "bus",
        "y": 28
      },
      {
        "x": "car",
        "y": 23
      },
      {
        "x": "moto",
        "y": 235
      },
      {
        "x": "bicycle",
        "y": 19
      },
      {
        "x": "horse",
        "y": 246
      },
      {
        "x": "skateboard",
        "y": 196
      },
      {
        "x": "others",
        "y": 200
      }
    ]
  },
  {
    "id": "france",
    color: tokens("dark").blueAccent[300],
    "data": [
      {
        "x": "plane",
        "y": 15
      },
      {
        "x": "helicopter",
        "y": 273
      },
      {
        "x": "boat",
        "y": 175
      },
      {
        "x": "train",
        "y": 3
      },
      {
        "x": "subway",
        "y": 223
      },
      {
        "x": "bus",
        "y": 168
      },
      {
        "x": "car",
        "y": 188
      },
      {
        "x": "moto",
        "y": 21
      },
      {
        "x": "bicycle",
        "y": 272
      },
      {
        "x": "horse",
        "y": 194
      },
      {
        "x": "skateboard",
        "y": 263
      },
      {
        "x": "others",
        "y": 93
      }
    ]
  },
  {
    "id": "us",
    color: tokens("dark").redAccent[200],
    "data": [
      {
        "x": "plane",
        "y": 233
      },
      {
        "x": "helicopter",
        "y": 29
      },
      {
        "x": "boat",
        "y": 129
      },
      {
        "x": "train",
        "y": 132
      },
      {
        "x": "subway",
        "y": 232
      },
      {
        "x": "bus",
        "y": 0
      },
      {
        "x": "car",
        "y": 103
      },
      {
        "x": "moto",
        "y": 263
      },
      {
        "x": "bicycle",
        "y": 69
      },
      {
        "x": "horse",
        "y": 260
      },
      {
        "x": "skateboard",
        "y": 86
      },
      {
        "x": "others",
        "y": 171
      }
    ]
  },
  {
    "id": "germany",
    "color": "hsl(174, 70%, 50%)",
    "data": [
      {
        "x": "plane",
        "y": 269
      },
      {
        "x": "helicopter",
        "y": 135
      },
      {
        "x": "boat",
        "y": 249
      },
      {
        "x": "train",
        "y": 215
      },
      {
        "x": "subway",
        "y": 282
      },
      {
        "x": "bus",
        "y": 98
      },
      {
        "x": "car",
        "y": 121
      },
      {
        "x": "moto",
        "y": 44
      },
      {
        "x": "bicycle",
        "y": 60
      },
      {
        "x": "horse",
        "y": 216
      },
      {
        "x": "skateboard",
        "y": 182
      },
      {
        "x": "others",
        "y": 63
      }
    ]
  },
  {
    "id": "norway",
    "color": "hsl(91, 70%, 50%)",
    "data": [
      {
        "x": "plane",
        "y": 126
      },
      {
        "x": "helicopter",
        "y": 84
      },
      {
        "x": "boat",
        "y": 24
      },
      {
        "x": "train",
        "y": 55
      },
      {
        "x": "subway",
        "y": 102
      },
      {
        "x": "bus",
        "y": 288
      },
      {
        "x": "car",
        "y": 216
      },
      {
        "x": "moto",
        "y": 254
      },
      {
        "x": "bicycle",
        "y": 211
      },
      {
        "x": "horse",
        "y": 3
      },
      {
        "x": "skateboard",
        "y": 42
      },
      {
        "x": "others",
        "y": 135
      }
    ]
  }
];


export const mockLineData3 = [
  {
    "id": "japan",
    color: tokens("dark").greenAccent[500],
    "data": [
      {
        "x": "plane",
        "y": 205
      },
      {
        "x": "helicopter",
        "y": 273
      },
      {
        "x": "boat",
        "y": 188
      },
      {
        "x": "train",
        "y": 224
      },
      {
        "x": "subway",
        "y": 137
      },
      {
        "x": "bus",
        "y": 103
      },
      {
        "x": "car",
        "y": 298
      },
      {
        "x": "moto",
        "y": 164
      },
      {
        "x": "bicycle",
        "y": 73
      },
      {
        "x": "horse",
        "y": 45
      },
      {
        "x": "skateboard",
        "y": 5
      },
      {
        "x": "others",
        "y": 161
      }
    ]
  },
  {
    "id": "france",
    color: tokens("dark").blueAccent[300],
    "data": [
      {
        "x": "plane",
        "y": 104
      },
      {
        "x": "helicopter",
        "y": 82
      },
      {
        "x": "boat",
        "y": 267
      },
      {
        "x": "train",
        "y": 271
      },
      {
        "x": "subway",
        "y": 238
      },
      {
        "x": "bus",
        "y": 204
      },
      {
        "x": "car",
        "y": 173
      },
      {
        "x": "moto",
        "y": 57
      },
      {
        "x": "bicycle",
        "y": 37
      },
      {
        "x": "horse",
        "y": 176
      },
      {
        "x": "skateboard",
        "y": 31
      },
      {
        "x": "others",
        "y": 244
      }
    ]
  },
  {
    "id": "us",
    color: tokens("dark").redAccent[200],
    "data": [
      {
        "x": "plane",
        "y": 11
      },
      {
        "x": "helicopter",
        "y": 128
      },
      {
        "x": "boat",
        "y": 159
      },
      {
        "x": "train",
        "y": 102
      },
      {
        "x": "subway",
        "y": 226
      },
      {
        "x": "bus",
        "y": 49
      },
      {
        "x": "car",
        "y": 180
      },
      {
        "x": "moto",
        "y": 103
      },
      {
        "x": "bicycle",
        "y": 34
      },
      {
        "x": "horse",
        "y": 221
      },
      {
        "x": "skateboard",
        "y": 30
      },
      {
        "x": "others",
        "y": 169
      }
    ]
  },
  {
    "id": "germany",
    "color": "hsl(245, 70%, 50%)",
    "data": [
      {
        "x": "plane",
        "y": 5
      },
      {
        "x": "helicopter",
        "y": 253
      },
      {
        "x": "boat",
        "y": 237
      },
      {
        "x": "train",
        "y": 62
      },
      {
        "x": "subway",
        "y": 227
      },
      {
        "x": "bus",
        "y": 178
      },
      {
        "x": "car",
        "y": 191
      },
      {
        "x": "moto",
        "y": 272
      },
      {
        "x": "bicycle",
        "y": 227
      },
      {
        "x": "horse",
        "y": 237
      },
      {
        "x": "skateboard",
        "y": 152
      },
      {
        "x": "others",
        "y": 88
      }
    ]
  },
  {
    "id": "norway",
    "color": "hsl(68, 70%, 50%)",
    "data": [
      {
        "x": "plane",
        "y": 280
      },
      {
        "x": "helicopter",
        "y": 45
      },
      {
        "x": "boat",
        "y": 183
      },
      {
        "x": "train",
        "y": 219
      },
      {
        "x": "subway",
        "y": 167
      },
      {
        "x": "bus",
        "y": 7
      },
      {
        "x": "car",
        "y": 68
      },
      {
        "x": "moto",
        "y": 95
      },
      {
        "x": "bicycle",
        "y": 202
      },
      {
        "x": "horse",
        "y": 26
      },
      {
        "x": "skateboard",
        "y": 43
      },
      {
        "x": "others",
        "y": 42
      }
    ]
  }
];


export const mockLineData4 = [
  {
    "id": "japan",
    color: tokens("dark").greenAccent[500],
    "data": [
      {
        "x": "plane",
        "y": 216
      },
      {
        "x": "helicopter",
        "y": 191
      },
      {
        "x": "boat",
        "y": 44
      },
      {
        "x": "train",
        "y": 160
      },
      {
        "x": "subway",
        "y": 99
      },
      {
        "x": "bus",
        "y": 79
      },
      {
        "x": "car",
        "y": 106
      },
      {
        "x": "moto",
        "y": 173
      },
      {
        "x": "bicycle",
        "y": 264
      },
      {
        "x": "horse",
        "y": 183
      },
      {
        "x": "skateboard",
        "y": 165
      },
      {
        "x": "others",
        "y": 182
      }
    ]
  },
  {
    "id": "france",
    color: tokens("dark").blueAccent[300],
    "data": [
      {
        "x": "plane",
        "y": 214
      },
      {
        "x": "helicopter",
        "y": 243
      },
      {
        "x": "boat",
        "y": 160
      },
      {
        "x": "train",
        "y": 160
      },
      {
        "x": "subway",
        "y": 59
      },
      {
        "x": "bus",
        "y": 4
      },
      {
        "x": "car",
        "y": 249
      },
      {
        "x": "moto",
        "y": 257
      },
      {
        "x": "bicycle",
        "y": 40
      },
      {
        "x": "horse",
        "y": 176
      },
      {
        "x": "skateboard",
        "y": 188
      },
      {
        "x": "others",
        "y": 275
      }
    ]
  },
  {
    "id": "us",
    color: tokens("dark").redAccent[200],
    "data": [
      {
        "x": "plane",
        "y": 294
      },
      {
        "x": "helicopter",
        "y": 32
      },
      {
        "x": "boat",
        "y": 180
      },
      {
        "x": "train",
        "y": 118
      },
      {
        "x": "subway",
        "y": 278
      },
      {
        "x": "bus",
        "y": 237
      },
      {
        "x": "car",
        "y": 61
      },
      {
        "x": "moto",
        "y": 157
      },
      {
        "x": "bicycle",
        "y": 169
      },
      {
        "x": "horse",
        "y": 190
      },
      {
        "x": "skateboard",
        "y": 168
      },
      {
        "x": "others",
        "y": 280
      }
    ]
  },
  {
    "id": "germany",
    "color": "hsl(14, 70%, 50%)",
    "data": [
      {
        "x": "plane",
        "y": 1
      },
      {
        "x": "helicopter",
        "y": 106
      },
      {
        "x": "boat",
        "y": 5
      },
      {
        "x": "train",
        "y": 277
      },
      {
        "x": "subway",
        "y": 23
      },
      {
        "x": "bus",
        "y": 157
      },
      {
        "x": "car",
        "y": 291
      },
      {
        "x": "moto",
        "y": 105
      },
      {
        "x": "bicycle",
        "y": 19
      },
      {
        "x": "horse",
        "y": 135
      },
      {
        "x": "skateboard",
        "y": 120
      },
      {
        "x": "others",
        "y": 240
      }
    ]
  },
  {
    "id": "norway",
    "color": "hsl(286, 70%, 50%)",
    "data": [
      {
        "x": "plane",
        "y": 7
      },
      {
        "x": "helicopter",
        "y": 110
      },
      {
        "x": "boat",
        "y": 120
      },
      {
        "x": "train",
        "y": 213
      },
      {
        "x": "subway",
        "y": 10
      },
      {
        "x": "bus",
        "y": 53
      },
      {
        "x": "car",
        "y": 158
      },
      {
        "x": "moto",
        "y": 90
      },
      {
        "x": "bicycle",
        "y": 212
      },
      {
        "x": "horse",
        "y": 50
      },
      {
        "x": "skateboard",
        "y": 127
      },
      {
        "x": "others",
        "y": 11
      }
    ]
  }
];






export const mockGeographyData = [
  {
    id: "AFG",
    value: 520600,
  },
  {
    id: "AGO",
    value: 949905,
  },
  {
    id: "ALB",
    value: 329910,
  },
  {
    id: "ARE",
    value: 675484,
  },
  {
    id: "ARG",
    value: 432239,
  },
  {
    id: "ARM",
    value: 288305,
  },
  {
    id: "ATA",
    value: 415648,
  },
  {
    id: "ATF",
    value: 665159,
  },
  {
    id: "AUT",
    value: 798526,
  },
  {
    id: "AZE",
    value: 481678,
  },
  {
    id: "BDI",
    value: 496457,
  },
  {
    id: "BEL",
    value: 252276,
  },
  {
    id: "BEN",
    value: 440315,
  },
  {
    id: "BFA",
    value: 343752,
  },
  {
    id: "BGD",
    value: 920203,
  },
  {
    id: "BGR",
    value: 261196,
  },
  {
    id: "BHS",
    value: 421551,
  },
  {
    id: "BIH",
    value: 974745,
  },
  {
    id: "BLR",
    value: 349288,
  },
  {
    id: "BLZ",
    value: 305983,
  },
  {
    id: "BOL",
    value: 430840,
  },
  {
    id: "BRN",
    value: 345666,
  },
  {
    id: "BTN",
    value: 649678,
  },
  {
    id: "BWA",
    value: 319392,
  },
  {
    id: "CAF",
    value: 722549,
  },
  {
    id: "CAN",
    value: 332843,
  },
  {
    id: "CHE",
    value: 122159,
  },
  {
    id: "CHL",
    value: 811736,
  },
  {
    id: "CHN",
    value: 593604,
  },
  {
    id: "CIV",
    value: 143219,
  },
  {
    id: "CMR",
    value: 630627,
  },
  {
    id: "COG",
    value: 498556,
  },
  {
    id: "COL",
    value: 660527,
  },
  {
    id: "CRI",
    value: 60262,
  },
  {
    id: "CUB",
    value: 177870,
  },
  {
    id: "-99",
    value: 463208,
  },
  {
    id: "CYP",
    value: 945909,
  },
  {
    id: "CZE",
    value: 500109,
  },
  {
    id: "DEU",
    value: 63345,
  },
  {
    id: "DJI",
    value: 634523,
  },
  {
    id: "DNK",
    value: 731068,
  },
  {
    id: "DOM",
    value: 262538,
  },
  {
    id: "DZA",
    value: 760695,
  },
  {
    id: "ECU",
    value: 301263,
  },
  {
    id: "EGY",
    value: 148475,
  },
  {
    id: "ERI",
    value: 939504,
  },
  {
    id: "ESP",
    value: 706050,
  },
  {
    id: "EST",
    value: 977015,
  },
  {
    id: "ETH",
    value: 461734,
  },
  {
    id: "FIN",
    value: 22800,
  },
  {
    id: "FJI",
    value: 18985,
  },
  {
    id: "FLK",
    value: 64986,
  },
  {
    id: "FRA",
    value: 447457,
  },
  {
    id: "GAB",
    value: 669675,
  },
  {
    id: "GBR",
    value: 757120,
  },
  {
    id: "GEO",
    value: 158702,
  },
  {
    id: "GHA",
    value: 893180,
  },
  {
    id: "GIN",
    value: 877288,
  },
  {
    id: "GMB",
    value: 724530,
  },
  {
    id: "GNB",
    value: 387753,
  },
  {
    id: "GNQ",
    value: 706118,
  },
  {
    id: "GRC",
    value: 377796,
  },
  {
    id: "GTM",
    value: 66890,
  },
  {
    id: "GUY",
    value: 719300,
  },
  {
    id: "HND",
    value: 739590,
  },
  {
    id: "HRV",
    value: 929467,
  },
  {
    id: "HTI",
    value: 538961,
  },
  {
    id: "HUN",
    value: 146095,
  },
  {
    id: "IDN",
    value: 490681,
  },
  {
    id: "IND",
    value: 549818,
  },
  {
    id: "IRL",
    value: 630163,
  },
  {
    id: "IRN",
    value: 596921,
  },
  {
    id: "IRQ",
    value: 767023,
  },
  {
    id: "ISL",
    value: 478682,
  },
  {
    id: "ISR",
    value: 963688,
  },
  {
    id: "ITA",
    value: 393089,
  },
  {
    id: "JAM",
    value: 83173,
  },
  {
    id: "JOR",
    value: 52005,
  },
  {
    id: "JPN",
    value: 199174,
  },
  {
    id: "KAZ",
    value: 181424,
  },
  {
    id: "KEN",
    value: 60946,
  },
  {
    id: "KGZ",
    value: 432478,
  },
  {
    id: "KHM",
    value: 254461,
  },
  {
    id: "OSA",
    value: 942447,
  },
  {
    id: "KWT",
    value: 414413,
  },
  {
    id: "LAO",
    value: 448339,
  },
  {
    id: "LBN",
    value: 620090,
  },
  {
    id: "LBR",
    value: 435950,
  },
  {
    id: "LBY",
    value: 75091,
  },
  {
    id: "LKA",
    value: 595124,
  },
  {
    id: "LSO",
    value: 483524,
  },
  {
    id: "LTU",
    value: 867357,
  },
  {
    id: "LUX",
    value: 689172,
  },
  {
    id: "LVA",
    value: 742980,
  },
  {
    id: "MAR",
    value: 236538,
  },
  {
    id: "MDA",
    value: 926836,
  },
  {
    id: "MDG",
    value: 840840,
  },
  {
    id: "MEX",
    value: 353910,
  },
  {
    id: "MKD",
    value: 505842,
  },
  {
    id: "MLI",
    value: 286082,
  },
  {
    id: "MMR",
    value: 915544,
  },
  {
    id: "MNE",
    value: 609500,
  },
  {
    id: "MNG",
    value: 410428,
  },
  {
    id: "MOZ",
    value: 32868,
  },
  {
    id: "MRT",
    value: 375671,
  },
  {
    id: "MWI",
    value: 591935,
  },
  {
    id: "MYS",
    value: 991644,
  },
  {
    id: "NAM",
    value: 701897,
  },
  {
    id: "NCL",
    value: 144098,
  },
  {
    id: "NER",
    value: 312944,
  },
  {
    id: "NGA",
    value: 862877,
  },
  {
    id: "NIC",
    value: 90831,
  },
  {
    id: "NLD",
    value: 281879,
  },
  {
    id: "NOR",
    value: 224537,
  },
  {
    id: "NPL",
    value: 322331,
  },
  {
    id: "NZL",
    value: 86615,
  },
  {
    id: "OMN",
    value: 707881,
  },
  {
    id: "PAK",
    value: 158577,
  },
  {
    id: "PAN",
    value: 738579,
  },
  {
    id: "PER",
    value: 248751,
  },
  {
    id: "PHL",
    value: 557292,
  },
  {
    id: "PNG",
    value: 516874,
  },
  {
    id: "POL",
    value: 682137,
  },
  {
    id: "PRI",
    value: 957399,
  },
  {
    id: "PRT",
    value: 846430,
  },
  {
    id: "PRY",
    value: 720555,
  },
  {
    id: "QAT",
    value: 478726,
  },
  {
    id: "ROU",
    value: 259318,
  },
  {
    id: "RUS",
    value: 268735,
  },
  {
    id: "RWA",
    value: 136781,
  },
  {
    id: "ESH",
    value: 151957,
  },
  {
    id: "SAU",
    value: 111821,
  },
  {
    id: "SDN",
    value: 927112,
  },
  {
    id: "SDS",
    value: 966473,
  },
  {
    id: "SEN",
    value: 158085,
  },
  {
    id: "SLB",
    value: 178389,
  },
  {
    id: "SLE",
    value: 528433,
  },
  {
    id: "SLV",
    value: 353467,
  },
  {
    id: "ABV",
    value: 251,
  },
  {
    id: "SOM",
    value: 445243,
  },
  {
    id: "SRB",
    value: 202402,
  },
  {
    id: "SUR",
    value: 972121,
  },
  {
    id: "SVK",
    value: 319923,
  },
  {
    id: "SVN",
    value: 728766,
  },
  {
    id: "SWZ",
    value: 379669,
  },
  {
    id: "SYR",
    value: 16221,
  },
  {
    id: "TCD",
    value: 101273,
  },
  {
    id: "TGO",
    value: 498411,
  },
  {
    id: "THA",
    value: 506906,
  },
  {
    id: "TJK",
    value: 613093,
  },
  {
    id: "TKM",
    value: 327016,
  },
  {
    id: "TLS",
    value: 607972,
  },
  {
    id: "TTO",
    value: 936365,
  },
  {
    id: "TUN",
    value: 898416,
  },
  {
    id: "TUR",
    value: 237783,
  },
  {
    id: "TWN",
    value: 878213,
  },
  {
    id: "TZA",
    value: 442174,
  },
  {
    id: "UGA",
    value: 720710,
  },
  {
    id: "UKR",
    value: 74172,
  },
  {
    id: "URY",
    value: 753177,
  },
  {
    id: "USA",
    value: 658725,
  },
  {
    id: "UZB",
    value: 550313,
  },
  {
    id: "VEN",
    value: 707492,
  },
  {
    id: "VNM",
    value: 538907,
  },
  {
    id: "VUT",
    value: 650646,
  },
  {
    id: "PSE",
    value: 476078,
  },
  {
    id: "YEM",
    value: 957751,
  },
  {
    id: "ZAF",
    value: 836949,
  },
  {
    id: "ZMB",
    value: 714503,
  },
  {
    id: "ZWE",
    value: 405217,
  },
  {
    id: "KOR",
    value: 171135,
  },
];