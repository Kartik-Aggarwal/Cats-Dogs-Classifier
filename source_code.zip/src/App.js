import { useState } from "react";
import { Routes, Route } from "react-router-dom";
import Topbar from "./scenes/global/Topbar";
import Sidebar from "./scenes/global/Sidebar";
import Dashboard from "./scenes/dashboard";
import Inventory from "./scenes/inventory/";
import InventoryDC from "./scenes/inventory/index.dc";
import InventoryWH from "./scenes/inventory/index_wh";
import InventoryRetail from "./scenes/inventory/index_retail";
import WorkQueues from "./scenes/work_queues";
import Bar from "./scenes/bar";
import Geography from "./scenes/geography";
import TopButton from "./components/TopButton";
import Supply from "./scenes/supply";
import Shippment from "./scenes/shippment";
// import Form from "./scenes/form";
import Line from "./scenes/line";
import Pie from "./scenes/pie";
// import FAQ from "./scenes/faq";
// import Geography from "./scenes/geography";
import { CssBaseline, ThemeProvider } from "@mui/material";
import { ColorModeContext, useMode } from "./theme";
import Objectives from "./scenes/objectives";
import Constraints from "./scenes/constraints";
import ModelInputs from "./scenes/model_inputs";
import RouteOptimizer from "./scenes/route_optimizer";
import ModelInputsTab from "./scenes/model_inputs_tabs";
import CustomernOrderF from "./scenes/customerNorder/index1";
import LocationNGeoF from "./scenes/locationNgeo/index1";
import CostnPerformanceF from "./scenes/costNperformance/index1";
import RouteOptimizer1 from "./scenes/route_optimizer/index1";
import Technician from "./scenes/technician";
import TechnicianF from "./scenes/technician/index1";
import Temp from "./scenes/temporary";
import ProductTable from "./components/tables/ProductTable";
import InventoryTable from "./components/tables/InventoryTable";
import DCTable from "./components/tables/DC table";
import TechniciansTable from "./components/tables/TechniciansTabel";
import VehicleTable from "./components/tables/VehicleTable";
import DriverTable from "./components/tables/DriverTable";
import DeliveryLaborTable from "./components/tables/DeliveryLaborTable";
import SCheduleOptimizer from "./scenes/schedule_optimizer";
import SCheduleOptimizer1 from "./scenes/schedule_optimizer/index1";
import TableCheckBox from "./components/ExcelTableCheck";
import DRO1 from "./scenes/dynamicRO/index1";
import DRO from "./scenes/dynamicRO";
// import Calendar from "./scenes/calendar/calendar";

function App() {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const toggleSidebar = () => {
    setIsCollapsed(!isCollapsed);
  };
  const [theme, colorMode] = useMode();
  const [isSidebar, setIsSidebar] = useState(true);
  const paddingL = isCollapsed ? '70px' : '240px'
  return (
    <ColorModeContext.Provider value={colorMode}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <div className="app">
          <Sidebar isSidebar={isSidebar} isCollapsed={isCollapsed} onToggleSidebar={toggleSidebar}/>
          <main className="content">
            <div style={{ flex: '1', paddingLeft: paddingL, overflowY: 'auto' }}>
            <Topbar setIsSidebar={setIsSidebar} />
            <Routes>
              <Route path="/" element={<Objectives />} />
              <Route path="/inventory" element={<Inventory />} />
              <Route path="/work_queues" element={<WorkQueues />} />
              <Route path="/route_optimizer" element={<RouteOptimizer />} />
              <Route path="/route_optimizer1" element={<RouteOptimizer1 />} />
              <Route path="/bar" element={<Bar />} />
              {/* <Route path="/inventory" element={<TopButton />} /> */}
              {/* <Route path="/form" element={<Form />} /> */}
              <Route path="/pie" element={<Pie />} />
              <Route path="/line" element={<Line />} />
              <Route path='/inventory/retail' element={<InventoryRetail />}/>
              <Route path='/inventory/warehouse' element={<InventoryWH />}/>
              <Route path='/inventory/distribution_center' element={<InventoryDC />}/>
              <Route path='/supply' element={<Supply />}/>
              <Route path='/shippment' element={<Shippment />}/>
              <Route path='/objectives' element={<Objectives />} />
              <Route path='/constraints' element={<Constraints />} />
              <Route path='/model_inputs' element={<ModelInputs />} />
              <Route path='/model_inputs_tab' element={<ModelInputsTab />} />
              {/* <Route path="/faq" element={<FAQ />} /> */}
              {/* <Route path="/calendar" element={<Calendar />} /> */}
              <Route path="/geography" element={<Geography />} />
              <Route path="/customer_order_F" element={<CustomernOrderF />} />
              <Route path="/LocationNGeoF" element={<LocationNGeoF />} />
              <Route path="/CostnPerformanceF" element={<CostnPerformanceF />} />
              <Route path="/technicianF" element={<TechnicianF />} />
              <Route path="/temp" element={<Temp />} />
              <Route path="/ProductTable" element={<ProductTable />} />
              <Route path="/InventoryTable" element={<InventoryTable />} />
              <Route path="/DCTable" element={<DCTable />} />
              <Route path="/TechniciansTable" element={<TechniciansTable />} />
              <Route path="/VehicleTable" element={<VehicleTable />} />
              <Route path="/DriverTable" element={<DriverTable />} />
              <Route path="/DeliveryLaborTable" element={<DeliveryLaborTable />} />
              <Route path="/schedule_optimiz" element={<SCheduleOptimizer />} />
              <Route path="/schedule_optimizer1" element={<SCheduleOptimizer1 />} />
              <Route path="/dynamic_route_optimizer" element={<DRO />} />
              <Route path="/dynamic_route_optimizer1" element={<DRO1 />} />

            </Routes>
            </div>
          </main>
        </div>
      </ThemeProvider>
    </ColorModeContext.Provider>
  );
}

export default App;


