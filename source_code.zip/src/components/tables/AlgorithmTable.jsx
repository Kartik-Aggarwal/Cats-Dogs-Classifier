import { Box, Button } from "@mui/material";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
// import { tokens } from "../../theme";
import { mockDataCustomernOrder } from "../../data/mockData";
import Header from "../../components/Header";
// import { useTheme } from "@mui/material";
// import CustomernOrder from ".";
import TopbarMini from "../../scenes/global/TopbarMini";
// import LocationNGeo from ".";
import ExcelTableNS from "../ExcelTableNoSelect";
import table from './AlgorithmTable.xlsx'
import { useState } from "react";
import * as XLSX from 'xlsx';


const AlgorithmExcelTable = () => {


    return (
    <Box m="20px">
          {/* HEADER */}
          <Box display="flex" justifyContent="space-between" alignItems="center">
            {/* <Header title="Model Inputs" subtitle="" />   */}
          </Box>
          {/* <TopbarMini /> */}
          <ExcelTableNS filePath={table}/>
    </Box>
    );
  };
  
  export default AlgorithmExcelTable;