import { Box, Button } from "@mui/material";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
// import { tokens } from "../../theme";
import { mockDataCustomernOrder } from "../../data/mockData";
import Header from "../../components/Header";
// import { useTheme } from "@mui/material";
// import CustomernOrder from ".";
import TopbarMini from "../../scenes/global/TopbarMini";
// import LocationNGeo from ".";
import ExcelTableNS from "../ExcelTableNoSelect";
import table from './DC table.xlsx'
import { useState } from "react";
import * as XLSX from 'xlsx';


const DCTable = () => {

    const handleFileUpload = () => {
      // Trigger file input click event
      document.getElementById('fileInput').click();
    };
  
    const handleFileChange = (event) => {
      // Handle file selection
      const selectedFile = event.target.files[0];
      console.log('Selected File:', selectedFile);
      // You can perform further operations with the selected file here
    };
    const handleClick3 = () => {
      window.location.href = '/DCTable';
      };


    return (
    <Box m="20px">
          {/* HEADER */}
          <Box sx={{marginBottom: '-15px'}} display="flex" justifyContent="space-between" alignItems="center">
            <Header title="Input Tables / Constraints" subtitle="" />  
          </Box>
          <TopbarMini buttonSelected={'button3'}/>
          <Header title="Distribution Center Details" subtitle="" />  
          <ExcelTableNS filePath={table}/>
          <>
          <input
            type="file"
            id="fileInput"
            style={{ display: 'none' }}
            onChange={handleFileChange}
          />
          </>
          <input type="file" id="fileInput" style={{display: 'none'}} onChange={handleFileChange}/>
          <Box sx={{marginTop: 4, marginLeft: 4, paddingBottom:10}} display="flex" justifyContent='flex-start' gap={7} alignItems="left">
          <Button onClick={handleClick3} variant="outlined"  size='large' sx={{width: '140px', backgroundColor: '#E2ECFF', transition: 'background-color 0.3s color 0.3s', '&:hover': {boxShadow:4, backgroundColor: '#6A9DFF', color: 'white'}}}><b>Refresh</b></Button>
          <Button onClick={handleFileUpload} variant="outlined"  size='large' sx={{width: '140px', backgroundColor: '#E2ECFF', transition: 'background-color 0.3s color 0.3s', '&:hover': {boxShadow:4, backgroundColor: '#6A9DFF', color: 'white'}}}><b>Upload</b></Button>
          <Button variant="outlined"  size='large' sx={{width: '140px', backgroundColor: '#E2ECFF', transition: 'background-color 0.3s color 0.3s', '&:hover': {boxShadow:4, backgroundColor: '#6A9DFF', color: 'white'}}}><b>Modify</b></Button>
          </Box>
    </Box>
    );
  };
  
  export default DCTable;