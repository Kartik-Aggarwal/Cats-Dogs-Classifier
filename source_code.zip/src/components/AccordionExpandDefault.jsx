import * as React from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ActionAreaCard2 from './card/Card2';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import Contacts from '../scenes/contacts';

const constraintData = [
  {
    title: 'Sales representative must return to starting location',
    description: 'Requiring the representative to return to the starting point ensures the completion of a round trip. This constraint impacts route planning significantly, influencing the sequence and order of visited locations to optimize both time and distance.',
  },
  {
    title: 'Time window constraints',
    description: 'Time windows specify the permissible time range for arriving at and departing from each location. Adhering to these constraints is crucial to meeting customer commitments and avoiding penalties for late deliveries, making route planning more complex but essential for customer satisfaction.',
  },
  {
    title: 'Capacity constraints if sales representative is carrying goods',
    description: 'If the sales representative is transporting goods, capacity constraints come into play. Each location may have a limit on the amount of goods that can be delivered or picked up, necessitating careful consideration in the route plan to avoid exceeding these limits.',
  },
  {
    title: 'Vehicle-specific and traffic-specific constraints',
    description: 'Different vehicles may have varying capabilities and limitations, such as maximum speed, weight limits, or fuel constraints. Traffic conditions and road characteristics also impact route optimization, requiring algorithms to account for these factors to ensure safe and efficient navigation. These constraints influence route decisions to optimize vehicle performance and compliance with regulations.',
  },
  {
    title: 'Geographical Constraints',
    description: 'Certain routes may be restricted due to geographical factors like road closures, bridges, tolls, or restricted areas. Route optimization algorithms must consider these constraints to plan feasible and legal paths.',
  },
  {
    title: 'Vehicle Types and Features',
    description: 'Different vehicles (e.g., trucks, vans, cars) have unique capabilities and limitations. Constraints such as vehicle dimensions, turning radius, and special equipment requirements (like refrigeration) affect route planning to ensure vehicle suitability for each segment of the journey.',
  },
  {
    title: 'Dynamic Traffic Conditions',
    description: 'Real-time traffic information influences route choices to avoid congestion and delays. Algorithms must incorporate traffic patterns, accidents, and road closures to adjust routes dynamically for optimal efficiency.',
  },
  {
    title: 'Environmental Factors',
    description: 'Constraints related to environmental regulations, emission zones, or eco-friendly routes may influence route selection to minimize ecological impact and adhere to sustainability goals.',
  },
  {
    title: 'Service Time Constraints',
    description: 'Some locations may require specific service times for tasks like loading/unloading or customer interactions. Meeting these constraints ensures operational efficiency and customer satisfaction.',
  },
  {
    title: 'Priority and Urgency',
    description: 'Certain deliveries or visits may have priority levels or urgency requirements. Algorithms must prioritize routes accordingly to meet critical deadlines and optimize overall delivery performance.',
  },
];


export default function AccordionExpandDefault() {
  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div>
      <React.Fragment>
        <div onClick={handleClickOpen}>
      <ActionAreaCard2 content={"Each location must be visited exactly once"}/>
      </div>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        fullWidth={true}
        maxWidth='xl'
        onClick={(e) => e.stopPropagation()}
      >
        <DialogTitle  id="alert-dialog-title">
        </DialogTitle>
        <DialogContent>
        <Contacts />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Close</Button>
          
        </DialogActions>
      </Dialog>
    </React.Fragment>



      <div style={{margin: 5, marginBottom: 10}}>
      <Accordion defaultExpanded elevation={1}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1-content"
          id="panel1-header"
        >
          <Typography sx={{ fontWeight: 'bold'}}>Each location must be visited exactly once</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
          This constraint ensures that every stop in the route is covered efficiently without revisiting the same location. By adhering to this rule, route optimization algorithms can focus on finding the shortest or most time-efficient path that fulfills all required visits.
          </Typography>
        </AccordionDetails>
      </Accordion>
      </div>

      {constraintData.map((constraint, index) => (
        <div style={{margin:5, marginBottom: 10}} >
        <Accordion key={index} elevation={1}>
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls={`panel${index + 1}-content`}
            id={`panel${index + 2}-header`}
          >
            <Typography sx={{ fontWeight: 'bold'}}>{constraint.title}</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>{constraint.description}</Typography>
          </AccordionDetails>
        </Accordion>
        </div>
      ))}
    </div>
  );
}
