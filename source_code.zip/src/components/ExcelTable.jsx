import React, { useState } from 'react';
import * as XLSX from 'xlsx';

const ExcelTable = () => {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) {
      setError('Please select a file.');
      return;
    }
    const reader = new FileReader();
    reader.onload = (event) => {
      const binaryString = event.target.result;
      const workbook = XLSX.read(binaryString, { type: 'binary' });
      const sheetName = workbook.SheetNames[0]; // Assuming first sheet is the one to be used
      const excelData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
      setData(excelData.slice(0, 150)); // Limiting to first 15 rows
    };
    reader.readAsBinaryString(file);
    setError(null); // Clear any previous errors
  };

  return (
    <div style={{ fontFamily: 'Arial, sans-serif' }}>
      <input type="file" onChange={handleFileUpload} style={{ marginBottom: '20px' }} />
      <div style={{ fontFamily: 'Arial, sans-serif', border: '2px solid #ddd', borderRadius: '5px', padding: '10px' }}>
      {error && <div style={{ color: 'red', marginBottom: '10px' }}>{error}</div>}
      {data && (
        <React.Fragment>
        <div style={{ maxHeight: '500px', overflowY: 'scroll' }}>
          <table style={{ borderCollapse: 'collapse', width: '100%' }}>
            <thead style={{ backgroundColor: '#E2ECFF' }}>
              <tr>
                {Object.keys(data[0]).map((key, index) => (
                  <th key={index} style={{ padding: '8px', border: '1px solid #ddd', textAlign: 'left' }}>
                    {key}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.map((row, index) => (
                <tr key={index}>
                  {Object.values(row).map((cell, index) => (
                    <td key={index} style={{ padding: '1px 0px 0px 10px', border: '1px solid #ddd', whiteSpace: 'pre-wrap' }}>
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
          </div>
          <div style={{ marginTop: '10px', textAlign: 'right', color:'#666' }}>
            Showing {data.length} of {data.length} rows
            </div>
        </React.Fragment>
      )}
    </div>
    </div>
  );
};

export default ExcelTable;
