import React, { useState } from 'react';
import { Button, Box, Checkbox, FormControlLabel, CircularProgress } from '@mui/material';

const RealtimeChecklist1 = () => {
  // State to manage whether the checklist should be visible
  const [showChecklist, setShowChecklist] = useState(false);
  // State to manage the checked state of each item
  const [checkedItems, setCheckedItems] = useState({
    item1: false,
    item2: false,
    item3: false,
    item4: false,
    item5: false,
    item6: false,
    item7: false,

  });
  // State to manage the loading state of checking items
  const [checkingItems, setCheckingItems] = useState(false);

  // Function to handle the "Check inputs" button click
  const handleCheckInputsClick = () => {
    // Show the checklist
    setShowChecklist(true);
    // Set loading state
    setCheckingItems(true);

    // Simulate real-time checking with a delay
    setTimeout(() => {
    //   setCheckingItems(true);
      setCheckedItems((prevCheckedItems) => ({
        ...prevCheckedItems,
        item1: true,
      }));
      setTimeout(() => {
        setCheckedItems((prevCheckedItems) => ({
          ...prevCheckedItems,
          item2: true,
        }));
        setTimeout(() => {
          setCheckedItems((prevCheckedItems) => ({
            ...prevCheckedItems,
            item3: true,
          }));
          setTimeout(() => {
            setCheckedItems((prevCheckedItems) => ({
              ...prevCheckedItems,
              item4: true,
            }));
            setTimeout(() => {
              setCheckedItems((prevCheckedItems) => ({
                ...prevCheckedItems,
                item5: true,
              }));
              setTimeout(() => {
                setCheckedItems((prevCheckedItems) => ({
                  ...prevCheckedItems,
                  item6: true,
                }));
                setTimeout(() => {
                    setCheckingItems(false);
                    setCheckedItems((prevCheckedItems) => ({
                      ...prevCheckedItems,
                      item7: true,
                    }));
                }, 2000);
            }, 1000);
            }, 1700);
          }, 300);
        }, 200);
      }, 2000);
    }, 1000);
  };

  return (
    <div>
        <Box sx={{ display: 'flex', gap: '40px', flexDirection: 'row', alignItems: 'center' }}>
      <Button variant="contained" onClick={handleCheckInputsClick} disabled={showChecklist}
      sx={{ width: '163px', fontSize:'large', mt: 4, bgcolor: 'primary.main', color: 'primary.contrastText', '&:hover': { bgcolor: 'primary.dark' } }}>
        Check inputs
      </Button>
      <Box sx={{ mt: 2 }}>
        <FormControlLabel
        componentsProps={{typography: {variant: 'h5'}}}
          control={<Checkbox checked={checkedItems.item1} sx={{ '&.Mui-checked': { color: 'green' } }} />}
          label="Distribution Center Details"
          disabled={showChecklist || checkingItems}
        />
        <FormControlLabel
        componentsProps={{typography: {variant: 'h5'}}}
          control={<Checkbox checked={checkedItems.item2} sx={{ '&.Mui-checked': { color: 'green' } }} />}
          label="Product Master"
          disabled={showChecklist || checkingItems}
        />
        <FormControlLabel
        componentsProps={{typography: {variant: 'h5'}}}
          control={<Checkbox checked={checkedItems.item3} sx={{ '&.Mui-checked': { color: 'green' } }} />}
          label="Inventory"
          disabled={showChecklist || checkingItems}
        />
        <FormControlLabel
        componentsProps={{typography: {variant: 'h5'}}}
          control={<Checkbox checked={checkedItems.item4} sx={{ '&.Mui-checked': { color: 'green' } }} />}
          label="Truck Details"
          disabled={showChecklist || checkingItems}
        />
        <FormControlLabel
        componentsProps={{typography: {variant: 'h5'}}}
          control={<Checkbox checked={checkedItems.item5} sx={{ '&.Mui-checked': { color: 'green' } }} />}
          label="Drivers Information"
          disabled={showChecklist || checkingItems}
        />
        <FormControlLabel
        componentsProps={{typography: {variant: 'h5'}}}
          control={<Checkbox checked={checkedItems.item6} sx={{ '&.Mui-checked': { color: 'green' } }} />}
          label="Delivery Staff Details"
          disabled={showChecklist || checkingItems}
        />
        <FormControlLabel
        componentsProps={{typography: {variant: 'h5'}}}
          control={<Checkbox checked={checkedItems.item7} sx={{ '&.Mui-checked': { color: 'green' } }} />}
          label="Technicians/Engineers Information"
          disabled={showChecklist || checkingItems}
        />
      </Box>
      {checkingItems && <CircularProgress size={50} />} {/* Show loading indicator while checking items */}
    </Box>
    </div>
  );
};

export default RealtimeChecklist1;
