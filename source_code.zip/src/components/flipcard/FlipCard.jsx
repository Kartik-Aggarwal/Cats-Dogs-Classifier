import React from "react";
import './FlipCard.css';
import ActionAreaCard from "../card/Card1";
import { Padding } from "@mui/icons-material";


const FlipCard = ({img, heading, content, back}) => {
    return(
        
            <div class="flip-card">
                <div class="flip-card-inner">
                    
                    <div class="flip-card-front" >
                    <div style={{display:'flex', flexDirection: 'row', justifyContent: 'center'}}>
                        <ActionAreaCard img={img} heading={heading} content={content} back={back}/>
                        </div>
                        {/* <p class="title">FLIP CARD</p>
                        <p>Hover Me</p> */}
                    </div>
                    <div class="flip-card-back" style={{ padding: '0px 10px'}}>
                        {/* <p class="title">{back}</p> */}
                        <p>{back}</p>
                    </div>
                </div>
            </div>
    );
};

export default FlipCard;
