import React, { useState } from 'react';
import { Card, CardContent, Typography, CardActionArea } from '@mui/material';
import './FlipCardR.css'; // Import CSS for styling
import CardMedia from '@mui/material/CardMedia';
import img1 from "./../assets/photos/geojango-maps-Z8UgB80_46w-unsplash.jpg";

const FlipCardR = () => {
  const [isFlipped, setIsFlipped] = useState(false);

  const handleCardFlip = () => {
    setIsFlipped(!isFlipped);
  };

  return (
    <Card
      sx={{ maxWidth: 345 }}
      className={`card ${isFlipped ? 'is-flipped' : ''}`}
      onMouseEnter={handleCardFlip}
      onMouseLeave={handleCardFlip}
    >
      <CardActionArea>
    <CardMedia
      component="img"
      height="140"
      image={img1}
      alt="green iguana"
    />
    <CardContent>
      <Typography gutterBottom variant="h5" component="div">
        Lizard
      </Typography>
      <Typography variant="body2" color="text.secondary">
        Lizards are a widespread group of squamate reptiles, with over 6,000
        species, ranging across all continents except Antarctica
      </Typography>
    </CardContent>
  </CardActionArea>
    </Card>
  );
};

export default FlipCardR;

// <Card sx={{ maxWidth: 345 }}>
//       <CardActionArea>
//         <CardMedia
//           component="img"
//           height="140"
//           image={img1}
//           alt="green iguana"
//         />
//         <CardContent>
//           <Typography gutterBottom variant="h5" component="div">
//             Lizard
//           </Typography>
//           <Typography variant="body2" color="text.secondary">
//             Lizards are a widespread group of squamate reptiles, with over 6,000
//             species, ranging across all continents except Antarctica
//           </Typography>
//         </CardContent>
//       </CardActionArea>
//     </Card>