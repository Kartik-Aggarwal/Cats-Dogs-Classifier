import React from 'react';
import { Dialog, DialogTitle, DialogContent } from '@mui/material';
import ReactPlayer from 'react-player';

const VideoDialog = ({ open, handleClose, videoPath }) => {
  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Video Dialog</DialogTitle>
      <DialogContent>
        {/* Embedding the video player */}
        <ReactPlayer url={videoPath} controls={true} width="100%" height="100%" />
      </DialogContent>
    </Dialog>
  );
};

export default VideoDialog;
