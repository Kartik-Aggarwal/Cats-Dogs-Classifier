import * as React from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import ExcelTable from './ExcelTable';
import table1S from './tables/Service1.xlsx'
import table2S from './tables/Service2.xlsx'
import table3S from './tables/Service3.xlsx'
import table4S from './tables/Service4.xlsx'
import table5S from './tables/Service5.xlsx'
import tableNS from './tables/Service6NDC.xlsx'
import table1D from './tables/Delivery1.xlsx'
import table2D from './tables/Delivery2.xlsx'
import table3D from './tables/Delivery3.xlsx'
import table4D from './tables/Delivery4.xlsx'
import table5D from './tables/Delivery5.xlsx'
import tableND from './tables/Delivery6NDC.xlsx'
import ExcelTableNS from './ExcelTableNoSelect';
import Header from './Header';




export default function SelectTextFields({ label, dict, ml=2}) {
  const [selectedOption, setSelectedOption] = React.useState('');

  const handleOptionChange = (event) => {
    setSelectedOption(event.target.value);
  };

  return (
    <Box
      component="form"
      sx={{
        '& .MuiTextField-root': { marginLeft: ml, marginBottom: 3, width: '45ch' },
      }}
      noValidate
      autoComplete="off"
    >
      <div>
        <TextField
          id="outlined-select-currency"
          select
          label={label}
          onChange={handleOptionChange}
          InputProps={{style: { fontSize: 20} }}
          InputLabelProps={{style: { fontSize: 18} }}
        //   defaultValue="EUR"
        //   helperText="Please select your currency"
        >
            
          {dict.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
        
        {selectedOption === 'DC201' && (<><Header size='h3' title={'Delivery Schedule for DC201'} /><ExcelTableNS filePath={table1D}/>
        <div style={{ height: '20px'}} />
        <Header size='h3' title={'Service Schedule for DC201'} /><ExcelTableNS filePath={table1S}/></>)}

        {selectedOption === 'DC202' && (<><Header size='h3' title={'Delivery Schedule for DC202'} /><ExcelTableNS filePath={table2D}/>
        <div style={{ height: '20px'}} />
        <Header size='h3' title={'Service Schedule for DC202'} /><ExcelTableNS filePath={table2S}/></>)}

        {selectedOption === 'DC203' && (<><Header size='h3' title={'Delivery Schedule for DC203'} /><ExcelTableNS filePath={table3D}/>
        <div style={{ height: '20px'}} />
        <Header size='h3' title={'Service Schedule for DC203'} /><ExcelTableNS filePath={table3S}/></>)}

        {selectedOption === 'DC204' && (<><Header size='h3' title={'Delivery Schedule for DC204'} /><ExcelTableNS filePath={table4D}/>
        <div style={{ height: '20px'}} />
        <Header size='h3' title={'Service Schedule for DC204'} /><ExcelTableNS filePath={table4S}/></>)}

        {selectedOption === 'DC205' && (<><Header size='h3' title={'Delivery Schedule for DC205'} /><ExcelTableNS filePath={table5D}/>
        <div style={{ height: '20px'}} />
        <Header size='h3' title={'Service Schedule for DC205'} /><ExcelTableNS filePath={table5S}/></>)}

        {selectedOption === 'NDC' && (<><Header size='h3' title={'Delivery Schedule for NDC'} /><ExcelTableNS filePath={tableND}/>
        <div style={{ height: '20px'}} />
        <Header size='h3' title={'Service Schedule for NDC'} /><ExcelTableNS filePath={tableNS}/></>)}

      </div>
    </Box>
  );
}