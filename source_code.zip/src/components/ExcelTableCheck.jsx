import React, { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';

const ExcelTableCheck = ({ filePath }) => {
  const [checkedItems, setCheckedItems] = useState({});

  // Function to handle checkbox change
  const handleCheckboxChange = (event, rowIndex) => {
    const { checked } = event.target;
    setCheckedItems({ ...checkedItems, [rowIndex]: checked });
  };

  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const binaryString = event.target.result;
      const workbook = XLSX.read(binaryString, { type: 'binary' });
      const sheetName = workbook.SheetNames[0]; // Assuming first sheet is the one to be used
      const excelData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
      setData(excelData); // Limiting to first 15 rows
    };
    reader.onerror = (event) => {
      setError('Failed to read file.');
    };

    fetch(filePath)
      .then((response) => response.blob())
      .then((blob) => {
        reader.readAsBinaryString(blob);
      })
      .catch(() => {
        setError('Failed to fetch file.');
      });
  }, [filePath]);

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', border: '2px solid #ddd', borderRadius: '5px', padding: '10px' }}>
      {error && <div style={{ color: 'red', marginBottom: '10px' }}>{error}</div>}
      {data && (
        <React.Fragment>
        <div style={{ maxHeight: '300px', overflowY: 'scroll' }}>
          <table style={{ borderCollapse: 'collapse', width: '100%' }}>
            <thead style={{ backgroundColor: '#E2ECFF' }}>
              <tr>
                  <th style={{ padding: '8px', border: '1px solid #ddd', textAlign: 'center' }}>
                    Jobs Done
                  </th>
                {Object.keys(data[0]).map((key, index) => (
                  <th key={index} style={{ padding: '8px', border: '1px solid #ddd', textAlign: 'center' }}>
                    {key}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.map((row, index) => (
                <tr key={index}>
                  <td style={{ padding: '1px 0px 0px 10px', border: '1px solid #ddd', whiteSpace: 'pre-wrap', textAlign: 'center' }}>
                  <input
                    type="checkbox"
                    checked={checkedItems[index] || false}
                    onChange={(event) => handleCheckboxChange(event, index)}
                  />
                  </td>
                  {Object.values(row).map((cell, index) => (
                    <td key={index} style={{ padding: '1px 0px 0px 10px', border: '1px solid #ddd', whiteSpace: 'pre-wrap', textAlign: 'center' }}>
                      {cell}
                    </td>
                  ))}
                  
                </tr>
              ))}
            </tbody>
          </table>
          </div>
          <div style={{ marginTop: '10px', textAlign: 'right', color:'#666' }}>
            Showing {data.length} of {data.length} rows
            </div>
        </React.Fragment>
      )}
    </div>
  );
};

export default ExcelTableCheck;

