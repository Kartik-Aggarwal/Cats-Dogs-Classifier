// Install dependencies
// npm install csv-parse react-chartjs-2 chart.js

import React, { useState, useEffect } from 'react';
import { Bar } from 'react-chartjs-2';
import { useTheme } from "@mui/material";
import { ResponsiveBar } from "@nivo/bar";
import { tokens } from "../theme";
import Papa from 'papaparse';

const BarChartFromCSV = ({ isDashboard = false }) => {
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  useEffect(() => {
    // Function to read CSV file
    const readCSV = async () => {
      try {
        const response = await fetch('./public/assets/Book.csv'); // Replace with the path to your CSV file
        const text = await response.text();
        const parsedData = Papa.parse(text, { header: true }).data;
        setData(parsedData);
        setIsLoading(false);
        console.log(parsedData);
      } catch (error) {
        console.error('Error reading CSV:', error);
      }
    };

    readCSV();
  }, []);

  // Process the data to format it for the chart
  const processDataForChart = () => {
    if (data.length === 0) {
      return null; // Return null if data is not available yet
    }

    // Example: Convert CSV data to dataset format expected by Chart.js
    const labels = data.map(entry => entry.label);
    const values = data.map(entry => entry.value);
    return {
      labels: labels,
      datasets: [
        {
          // label: 'Data from CSV',
          // backgroundColor: 'rgba(75,192,192,1)',
          // borderColor: 'rgba(0,0,0,1)',
          // borderWidth: 2,
          data: values,
        },
      ],
    };
  };


return (
  <div>
  <h2>Bar Chart from CSV Data</h2>
  {isLoading ? (
    <p>Loading...</p> // Display loading indicator while data is being fetched
  ) : (

  <ResponsiveBar
    data={processDataForChart()}
    theme={{
      // added
      axis: {
        domain: {
          line: {
            stroke: colors.grey[100],
          },
        },
        legend: {
          text: {
            fill: colors.grey[100],
          },
        },
        ticks: {
          line: {
            stroke: colors.grey[100],
            strokeWidth: 1,
          },
          text: {
            fill: colors.grey[100],
          },
        },
      },
      legends: {
        text: {
          fill: colors.grey[100],
        },
      },
    }}
    keys={["SKU1", "SKU2", "SKU3", "SKU4", "SKU5", "SKU6", "SKU7"]}
    indexBy="country"
    margin={{ top: 50, right: 130, bottom: 50, left: 60 }}
    padding={0.3}
    valueScale={{ type: "linear" }}
    indexScale={{ type: "band", round: true }}
    colors={{ scheme: "nivo" }}
    defs={[
      {
        id: "dots",
        type: "patternDots",
        background: "inherit",
        color: "#38bcb2",
        size: 4,
        padding: 1,
        stagger: true,
      },
      {
        id: "lines",
        type: "patternLines",
        background: "inherit",
        color: "#eed312",
        rotation: -45,
        lineWidth: 6,
        spacing: 10,
      },
    ]}
    borderColor={{
      from: "color",
      modifiers: [["darker", "1.6"]],
    }}
    axisTop={null}
    axisRight={null}
    axisBottom={{
      tickSize: 5,
      tickPadding: 5,
      tickRotation: 0,
      legend: isDashboard ? undefined : "country", // changed
      legendPosition: "middle",
      legendOffset: 32,
    }}
    axisLeft={{
      tickSize: 5,
      tickPadding: 5,
      tickRotation: 0,
      legend: isDashboard ? undefined : "food", // changed
      legendPosition: "middle",
      legendOffset: -40,
    }}
    enableLabel={false}
    labelSkipWidth={12}
    labelSkipHeight={12}
    labelTextColor={{
      from: "color",
      modifiers: [["darker", 1.6]],
    }}
    legends={[
      {
        dataFrom: "keys",
        anchor: "bottom-right",
        direction: "column",
        justify: false,
        translateX: 120,
        translateY: 0,
        itemsSpacing: 2,
        itemWidth: 100,
        itemHeight: 20,
        itemDirection: "left-to-right",
        itemOpacity: 0.85,
        symbolSize: 20,
        effects: [
          {
            on: "hover",
            style: {
              itemOpacity: 1,
            },
          },
        ],
      },
    ]}
    role="application"
    barAriaLabel={function (e) {
      return e.id + ": " + e.formattedValue + " in country: " + e.indexValue;
    }}
  />
)}
</div>
);
};


export default BarChartFromCSV;