import Button from '@mui/material/Button';
import { Link } from 'react-router-dom';


const TopButton = ({ title }) => {

return(
<Button variant="outlined" size='large'><b>{title}</b> <Link to={"/"} /></Button>
);
};

export default TopButton;