import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import { themeSettings, tokens } from "../theme";
import { useTheme, Box } from "@mui/material"; 

function TempTopBar() {
  const [anchorEl, setAnchorEl] = useState(null);
  const history = useNavigate();
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = (page) => {
    setAnchorEl(null);
    if (page) {
        history(page); // Navigate to the selected page
    };
};




  const handleMenuClose = () => {
        setAnchorEl(null);
    };

  return (
    
    <AppBar style={{marginTop: -16}} position="static" color='default' elevation={0} sx={{bgcolor: '#fcfcfc'}}>
      <Toolbar>
        <Button style={{marginLeft: -16, width: 101}} variant='outlined' aria-controls="simple-menu" aria-haspopup="true" onClick={handleClick} color="inherit">
          Location
        </Button>
        <Menu
          id="simple-menu"
          anchorEl={anchorEl}   
          keepMounted
          open={Boolean(anchorEl)}
          onClose={handleMenuClose}
        >
          <MenuItem onClick={() => handleClose('/inventory/retail')}>Retailer</MenuItem>
          <MenuItem onClick={() => handleClose('/inventory/warehouse')}>Warehouse</MenuItem>
          <MenuItem onClick={() => handleClose('/inventory/distribution_center')}>Distribution center</MenuItem>
        </Menu>
      </Toolbar>
    </AppBar>
  );
}

export default TempTopBar;

