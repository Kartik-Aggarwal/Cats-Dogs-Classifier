import * as React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';
import img1 from './assets/photos/hover.png';

const HoverImgBox = ({ img, heading, content }) => {  
  return (
    
    <Card sx={{ width: 950, height: 415, borderRadius: '1.2rem', '&:hover': {
        '& .MuiCardMedia-img': {
          // Your hover image URL or any other styles
          // For example:
          content: `url(${img1})`, // Replace with your hover image URLsrc\components\
        },
      },
      '& .MuiCardMedia-img': {
        transition: '0.3s',
      },
      }}>
      <CardActionArea>
        <CardMedia
          component="img"
          height="415"//195/295
          image={img}
          alt="green iguana"
        />
        <CardContent>
          <Typography gutterBottom variant="h3" component="div">
            {heading}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {content}
          </Typography>
        </CardContent>
      </CardActionArea>
    </Card>
    
    
  );
}

export default HoverImgBox;