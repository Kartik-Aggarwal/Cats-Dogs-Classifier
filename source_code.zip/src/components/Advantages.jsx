
import React from 'react';

const Advantages = ({ advantages }) => {
  return (
    <div>
      <h2>Benifits expected</h2>
      <ul>
        {advantages.map((advantage, index) => (
          <li key={index} style={{fontSize: 16}}>{advantage}</li>
        ))}
      </ul>
    </div>
  );
};

export default Advantages;
