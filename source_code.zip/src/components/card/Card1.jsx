import * as React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';

const ActionAreaCard = ({ img, heading, content }) => {  
  return (
    <Card sx={{ minWidth: 370, maxWidth: 645, minHeight: 300, borderRadius: '1.2rem'}}>
      <CardActionArea>
        <CardMedia
          component="img"
          height="180"
          image={img}
          alt="green iguana"
        />
        <CardContent>
          <Typography gutterBottom variant="h3" component="div" sx={{marginTop: '15px'}}>
            {heading}
          </Typography>
          {/* <Typography variant="body2" color="text.secondary">
            {content}
          </Typography> */}
        </CardContent>
      </CardActionArea>
    </Card>
  );
}

export default ActionAreaCard;