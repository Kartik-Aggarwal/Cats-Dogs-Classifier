import * as React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';


const ActionAreaCard3 = () => {  
  return (
    <Card sx={{ maxWidth: 545, borderRadius: '1.2rem'}}>
      <CardActionArea>
        <CardMedia
          component="img"
          height="180"
          image={img3}
          alt="green iguana"
        />
        <CardContent>
          <Typography gutterBottom variant="h5" component="div">
            asdas
          </Typography>
          <Typography variant="body2" color="text.secondary">
            content
          </Typography>
        </CardContent>
      </CardActionArea>
    </Card>
  );
}

export default ActionAreaCard3;