import React, { useState } from 'react';
import { Button, Box, Checkbox, FormControlLabel, CircularProgress, Typography } from '@mui/material';

const RealtimeChecklist = () => {
  // State to manage whether the checklist should be visible
  const [showChecklist, setShowChecklist] = useState(false);
  // State to manage the checked state of each item
  const [checkedItems, setCheckedItems] = useState({
    item1: false,
    item2: false,
    item3: false,
    item4: false,
    item5: false,
  });
  // State to manage the loading state of checking items
  const [checkingItems, setCheckingItems] = useState(false);

  // Function to handle the "Check inputs" button click
  const handleCheckInputsClick = () => {
    // Show the checklist
    setShowChecklist(true);
    // Set loading state
    setCheckingItems(true);

    // Simulate real-time checking with a delay
    setTimeout(() => {
      setCheckingItems(false);
      setCheckedItems({
        item1: true,
        item2: true,
        item3: true,
        item4: true,
        item5: true,
      });
    }, 1000 * 6); // 1 second delay for each of the 5 items
  };

  return (
    <Box sx={{ display: 'flex', gap: '90px', flexDirection: 'row', alignItems: 'center' }}>
      <Button
        variant="contained"
        onClick={handleCheckInputsClick}
        disabled={showChecklist}
        sx={{ fontSize:'large', mt: 4, bgcolor: 'primary.main', color: 'primary.contrastText', '&:hover': { bgcolor: 'primary.dark' } }}
      >
        Check inputs
      </Button>
      {checkingItems && <CircularProgress sx={{ mt: 2 }} />} {/* Show loading indicator while checking items */}
      {showChecklist && (
        <Box sx={{ mt: 2 }}>
          {/* <Typography variant="h6">Checklist</Typography> */}
          <FormControlLabel
          componentsProps={{typography: {variant: 'h5'}}}
            control={<Checkbox checked={checkedItems.item1} sx={{ '&.Mui-checked': { color: 'green' } }} />}
            label="Product Details"
            disabled={checkingItems}
            sx={{ mt: 1 }}
          />
          <FormControlLabel
            componentsProps={{typography: {variant: 'h5'}}}
            control={<Checkbox checked={checkedItems.item2} sx={{ '&.Mui-checked': { color: 'green' } }} />}
            label="Inventory Details"
            disabled={checkingItems}
            sx={{ mt: 1}}
          />
          <FormControlLabel
          componentsProps={{typography: {variant: 'h5'}}}
            control={<Checkbox checked={checkedItems.item3} sx={{ '&.Mui-checked': { color: 'green' } }} />}
            label="DC Details"
            disabled={checkingItems}
            sx={{ mt: 1 }}
          />
          <FormControlLabel
          componentsProps={{typography: {variant: 'h5'}}}
            control={<Checkbox checked={checkedItems.item4} sx={{ '&.Mui-checked': { color: 'green' } }} />}
            label="Technicians Details"
            disabled={checkingItems}
            sx={{ mt: 1 }}
          />
          <FormControlLabel
          componentsProps={{typography: {variant: 'h5'}}}
            control={<Checkbox checked={checkedItems.item5} sx={{ '&.Mui-checked': { color: 'green' } }} />}
            label="Vehicle Details"
            disabled={checkingItems}
            sx={{ mt: 1 }}
          />
          <FormControlLabel
          componentsProps={{typography: {variant: 'h5'}}}
            control={<Checkbox checked={checkedItems.item5} sx={{ '&.Mui-checked': { color: 'green' } }} />}
            label="Driver Details"
            disabled={checkingItems}
            sx={{ mt: 1 }}
          />
          <FormControlLabel
          componentsProps={{typography: {variant: 'h5'}}}
            control={<Checkbox checked={checkedItems.item5} sx={{ '&.Mui-checked': { color: 'green' } }} />}
            label="Delivery Details"
            disabled={checkingItems}
            sx={{ mt: 1 }}
          />
        </Box>
      )}
      
    </Box>
  );
};

export default RealtimeChecklist;