import React, { useState } from 'react';

const ImageBox = ({ hover, default_img }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        width: '900px',
        height: '200px',
        border: '1px solid black',
        overflow: 'hidden',
      }}
    >
      {isHovered ? (
        <img
          src={hover}
          alt="Hover Image"
        //   style={{ width: '100%', height: '100%' }}
        />
      ) : (
        <img
          src={default_img}
          alt="Default Image"
        //   style={{ width: '100%', height: '100%' }}
        />
      )}
    </div>
  );
};

export default ImageBox;
