import React from "react";
import { Box, Typography } from "@mui/material";

const CustomBox = ({text}) => {
        <Box
        gridColumn="span 6"
        gridRow="span 1"
        backgroundColor={'#f2f0f0'}
        display="flex"
        alignItems="center"
        justifyContent="center"
        >
        <Typography gutterBottom variant="h5" component="div">
        {text}  
        </Typography>
    </Box>
    };

export default CustomBox;