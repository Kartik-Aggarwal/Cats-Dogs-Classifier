import * as React from 'react';
import { Box, CardActionArea, Typography } from "@mui/material";
import AccordionExpandDefault from "../../components/AccordionExpandDefault";
import Header from "../../components/Header";
import ActionAreaCard2 from "../../components/card/Card2";
import CustomBox from "./CustomBox";
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import Contacts from '../contacts';
import Button from '@mui/material/Button';
import Trucks from '../truck';
import GeoCons from '../geocons';
import TimeCons from '../timecons';


const Constraints = () => {
    const [open_trucks, setOpen_trucks] = React.useState(false);
    const [open_geo, setOpen_geo] = React.useState(false);
    const [open_contacts, setOpen_contacts] = React.useState(false);
    const [open_time, setOpen_time] = React.useState(false);


    const handleClickOpen_trucks = () => {
      setOpen_trucks(true);
    };
    const handleClickOpen_geo = () => {
        setOpen_geo(true);
    };
    const handleClickOpen_contacts = () => {
      setOpen_contacts(true);
    };
    const handleClickOpen_time = () => {
      setOpen_time(true);
    };
    
  
    const handleClose = () => {
      setOpen_trucks(false);
      setOpen_geo(false);
      setOpen_contacts(false);
      setOpen_time(false);
    };  

    return (
        <Box m="20px">
            <Box display="flex" justifyContent="space-between" alignItems="center">
                <Header title="Constraints" subtitle="" />
            </Box>
            {/* <AccordionExpandDefault/> */}

            <Box
                display="grid"
                gridTemplateColumns="repeat(12, 1fr)"
                // gridTemplateRows="repeat(1, 3fr)"
                gridAutoRows="70px"
                gap="20px"
            >

                {/* <React.Fragment>
                    <Box gridColumn="span 6" gridRow="span 1" backgroundColor={'#f2f0f0'} display="flex" alignItems="center" justifyContent="center" onClick={handleClickOpen_trucks}
                    sx={{transition: 'background-color 0.3s', '&:hover': {backgroundColor: '#ddd', boxShadow:4}}}>
                    <Typography gutterBottom variant="h5" component="div">
                    Each location must be visited exactly once 
                    </Typography>
                    </Box>
                    <Dialog
                    open={open_trucks}
                    onClose={handleClose}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                    fullWidth={true}
                    maxWidth='lg'
                    onClick={(e) => e.stopPropagation()}
                    >
                    <DialogTitle  id="alert-dialog-title">
                    </DialogTitle>
                    <DialogContent>
                    <GeoCons />
                    </DialogContent>
                    <DialogActions>
                    <Button onClick={handleClose}>Close</Button>
                    </DialogActions>
                    </Dialog>
                </React.Fragment>

                <React.Fragment>
                    <Box gridColumn="span 6" gridRow="span 1" backgroundColor={'#f2f0f0'} display="flex" alignItems="center" justifyContent="center" onClick={handleClickOpen_geo}
                    sx={{transition: 'background-color 0.3s', '&:hover': {backgroundColor: '#ddd', boxShadow:4}}}>
                    <Typography gutterBottom variant="h5" component="div">
                    Sales representative must return to starting location 
                    </Typography>
                    </Box>
                    <Dialog
                    open={open_geo}
                    onClose={handleClose}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                    fullWidth={true}
                    maxWidth='lg'
                    onClick={(e) => e.stopPropagation()}
                    >
                    <DialogTitle  id="alert-dialog-title">
                    </DialogTitle>
                    <DialogContent>
                    <Trucks />
                    </DialogContent>
                    <DialogActions>
                    <Button onClick={handleClose}>Close</Button>
                    </DialogActions>
                    </Dialog>
                </React.Fragment> */}

                <React.Fragment>
                    <Box gridColumn="span 6" gridRow="span 1" backgroundColor={'#f2f0f0'} display="flex" alignItems="center" justifyContent="center" onClick={handleClickOpen_time}
                    sx={{transition: 'background-color 0.3s', '&:hover': {backgroundColor: '#ddd', boxShadow:4}}}>
                    <Typography gutterBottom variant="h5" component="div">
                    Time window constraints 
                    </Typography>
                    </Box>
                    <Dialog
                    open={open_time}
                    onClose={handleClose}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                    fullWidth={true}
                    maxWidth='lg'
                    onClick={(e) => e.stopPropagation()}
                    >
                    <DialogTitle  id="alert-dialog-title">
                    </DialogTitle>
                    <DialogContent>
                    <TimeCons />
                    </DialogContent>
                    <DialogActions>
                    <Button onClick={handleClose}>Close</Button>
                    </DialogActions>
                    </Dialog>
                </React.Fragment>

                    {/* <Box gridColumn="span 6" gridRow="span 1" backgroundColor={'#f2f0f0'} display="flex" alignItems="center" justifyContent="center" onClick={handleClickOpen_trucks}
                    sx={{transition: 'background-color 0.3s', '&:hover': {backgroundColor: '#ddd', boxShadow:4}}}>
                    <Typography gutterBottom variant="h5" component="div">
                    Capacity constraints if sales representative is carrying goods 
                    </Typography>
                    </Box> */}


                <React.Fragment>
                    <Box gridColumn="span 6" gridRow="span 1" backgroundColor={'#f2f0f0'} display="flex" alignItems="center" justifyContent="center" onClick={handleClickOpen_geo}
                    sx={{transition: 'background-color 0.3s', '&:hover': {backgroundColor: '#ddd', boxShadow:4}}}>
                    <Typography gutterBottom variant="h5" component="div">
                    Geographical Constraints 
                    </Typography>
                    </Box>
                    <Dialog
                    open={open_geo}
                    onClose={handleClose}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                    fullWidth={true}
                    maxWidth='lg'
                    onClick={(e) => e.stopPropagation()}
                    >
                    <DialogTitle  id="alert-dialog-title">
                    </DialogTitle>
                    <DialogContent>
                    <GeoCons />
                    </DialogContent>
                    <DialogActions>
                    <Button onClick={handleClose}>Close</Button>
                    </DialogActions>
                    </Dialog>
                </React.Fragment>
                
                <React.Fragment>
                    <Box gridColumn="span 6" gridRow="span 1" backgroundColor={'#f2f0f0'} display="flex" alignItems="center" justifyContent="center" onClick={handleClickOpen_trucks}
                    sx={{transition: 'background-color 0.3s', '&:hover': {backgroundColor: '#ddd', boxShadow:4}}}>
                    <Typography gutterBottom variant="h5" component="div">
                    Vehicle Types and Features 
                    </Typography>
                    </Box>
                    <Dialog
                    open={open_trucks}
                    onClose={handleClose}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                    fullWidth={true}
                    maxWidth='lg'
                    onClick={(e) => e.stopPropagation()}
                    >
                    <DialogTitle  id="alert-dialog-title">
                    </DialogTitle>
                    <DialogContent>
                    <Trucks />
                    </DialogContent>
                    <DialogActions>
                    <Button onClick={handleClose}>Close</Button>
                    </DialogActions>
                    </Dialog>
                </React.Fragment>

                    {/* <Box gridColumn="span 6" gridRow="span 1" backgroundColor={'#f2f0f0'} display="flex" alignItems="center" justifyContent="center" onClick={handleClickOpen_trucks}
                    sx={{transition: 'background-color 0.3s', '&:hover': {backgroundColor: '#ddd', boxShadow:4}}}>
                    <Typography gutterBottom variant="h5" component="div">
                    Dynamic Traffic Conditions 
                    </Typography>
                    </Box>

                    <Box gridColumn="span 6" gridRow="span 1" backgroundColor={'#f2f0f0'} display="flex" alignItems="center" justifyContent="center" onClick={handleClickOpen_trucks}
                    sx={{transition: 'background-color 0.3s', '&:hover': {backgroundColor: '#ddd', boxShadow:4}}}>
                    <Typography gutterBottom variant="h5" component="div">
                    Vehicle-specific and traffic-specific constraints    
                    </Typography>
                    </Box> */}

            </Box>
            </Box>
    );
};

export default Constraints;