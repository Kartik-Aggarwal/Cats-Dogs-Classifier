import { Box } from "@mui/material";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { tokens } from "../../theme";
import Header from "../../components/Header";
import { useTheme } from "@mui/material";
import { mockDataCostnPerformanceMetrics } from "../../data/mockData";
import { Style } from "@mui/icons-material";

const CostnPerformance = () => {
    const customStyles = {
        components: {
          Cell: {
            style: {
              fontSize: '26px', // Adjust the font size as needed
            },
          },
        },
      };
    
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

     
  const columns = [
    { field: "id", headerName: "ID", flex: 0.1 ,headerAlign: "center",
    align: "center",},
    { field: "vehicleId", headerName: "Vehicle Id" , flex: 0.1,headerAlign: "center",
    align: "center"},
    {
      field: "fuelCost",
      headerName: "Fuel Cost (USD/gallon)",
      flex: 0.1,
      cellClassName: "name-column--cell",
      headerAlign: "center",
      align: "center",
    },
    {
      field: "laborCost",
      headerName: "Labor Cost (USD/hour)",
      type: "number",
      headerAlign: "center",
      align: "center",
      flex: 0.1
    },
  ];

  return (
    <Box m="20px">
      <Header
        title="Cost and Performance Metrics"//"CONTACTS"
        // subtitle="List of Contacts for Future Reference"
      />
      <Box
        m="40px 0 0 0"
        height="75vh"
        
        sx={{
          "& .MuiDataGrid-root": {
            border: "none",
            fontSize: 20
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
            fontSize: 15    
          },
          "& .name-column--cell": {
            color: colors.greenAccent[300],
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blueAccent[700],
            borderBottom: "none",
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.primary[400],
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "none",
            backgroundColor: colors.blueAccent[700],
          },
          "& .MuiCheckbox-root": {
            color: `${colors.greenAccent[200]} !important`,
          },
          "& .MuiDataGrid-toolbarContainer .MuiButton-text": {
            color: `${colors.grey[100]} !important`,
          },
        }}
      >
        <style>
        {`
          .MuiDataGrid-root .MuiDataGrid-colCellWrapper,
          .MuiDataGrid-root .MuiDataGrid-cell {
            border-right: 1px solid #e0e0e0;
            border-bottom: 1px solid #e0e0e0;
          }
        `}
      </style>
        <DataGrid
          rows={mockDataCostnPerformanceMetrics}
          columns={columns}
          components={{ Toolbar: GridToolbar }}
          componentsProps={customStyles}
          showCellVerticalBorder
          
        />
      </Box>
    </Box>
  );
};

export default CostnPerformance;
