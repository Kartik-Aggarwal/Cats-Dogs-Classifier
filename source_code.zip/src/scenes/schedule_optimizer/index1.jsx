import Header from "../../components/Header";
import { Box, IconButton, useTheme } from "@mui/material";
import { useContext, useState } from "react";
import { ColorModeContext, tokens } from "../../theme";
import InputBase from "@mui/material/InputBase";
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import NotificationsOutlinedIcon from "@mui/icons-material/NotificationsOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import PersonOutlinedIcon from "@mui/icons-material/PersonOutlined";
import SearchIcon from "@mui/icons-material/Search";
import Stack from '@mui/material/Stack';
import BasicMenu from "../../components/DropDB";
import DemandData from "../demand_data";
import SelectTextFields from "../../components/DropDownMenu";
import ExcelTableNS from "../../components/ExcelTableNoSelect";
import table from '../../components/tables/Demand Data.xlsx'
import RealtimeChecklist from "../../components/CheckList";
import React from 'react';
import { Button, CircularProgress } from '@mui/material';
import RealtimeChecklist1 from "../../components/CheckList2";



const RunButton = () => {
  const algo = [
    {
      value: 'DC201',
      label: 'DC201 Schedule',
    },
    {
      value: 'DC202',
      label: 'DC202 Schedule',
    },  
    {
      value: 'DC203',
      label: 'DC203 Schedule',
    }, 
    {
      value: 'DC204',
      label: 'DC204 Schedule',
    }, 
    {
      value: 'DC205',
      label: 'DC205 Schedule',
    }, 
    {
      value: 'NDC',
      label: 'NDC Schedule',
    },  
     
  ];

  // State to manage the loading state of running
  const [running, setRunning] = useState(false);
  const [pressed, setPressed] = useState(false);


  // Function to handle the "Run" button click
  const handleRunClick = () => {
    // Set running state
    setRunning(true);
    setPressed(true);

    // Simulate running with a delay
    setTimeout(() => {
      setRunning(false);
    }, 5000); // Simulating a 3-second delay for fake loading
  };

  return (
    
    <div style={{ marginTop: 30, paddingBottom: 30, textAlign: 'left' }}>
      <Stack direction='row' gap={10}>
      <Button
        variant="contained"
        onClick={handleRunClick}
        disabled={running}
        sx={{ fontSize: '1.2rem', width: '140px', height:'50px', mt: 2, bgcolor: 'primary.main', color: 'primary.contrastText', '&:hover': { bgcolor: 'primary.dark' } }}
      >
        {running ? <CircularProgress size={24} sx={{ color: 'white' }} /> : 'Run'}
      </Button>
      {running && <p style={{ fontSize: '1.2rem'}}>Runnning Scheduling Optimizer Model...</p>}
      </Stack>
      {!running && pressed && <div style={{marginTop: 50}}><SelectTextFields ml={0} label={'Choose Distribution Center'} dict={algo}/></div>} {/* Render the Table component after running completes */}
      {/* {!running && pressed && <div style={{marginTop: 50}}><ExcelTableNS filePath={table}/></div>} Render the Table component after running completes */}
    </div>
  );
};




const SCheduleOptimizer1 = () => {
    const obj_func = [
        {
          value: 'USD',
          label: 'Minimise Cost',
        },
        {
          value: 'EUR',
          label: 'Maximise Profit',
        },
        {
          value: 'BTC',
          label: 'Minimise Time',
        },
        {
          value: 'JPY',
          label: 'Maximise Efficiency',
        },
        {
          value: 'JPY',
          label: 'Minimise Distance',
        },
      ];
    


    const [clicked, setClicked] = useState(false);
    const [clickedC, setClickedC] = useState(false);
    const handleClickButt = () => {
        setTimeout(() => {
            setClicked(true);
        }, 2000);
    };

    const handleClickCompute = () => {
        setClickedC(true);
    };


    const theme = useTheme();
    const colors = tokens(theme.palette.mode);
    const colorMode = useContext(ColorModeContext);
    const handleClick = () => {
        window.location.href = '/schedule_optimizer1';
        };

    return (
        <Box m="20px">
            <Box display="flex" justifyContent="space-between" alignItems="center">
                <Header title="Schedule Optimizer" subtitle="" />
            </Box>
            
            <Box display="flex" justifyContent="left" mb={2}>
            <Box
                display="flex"
                backgroundColor={colors.primary[400]}
                borderRadius="3px"
                marginBottom={4}
            >
                {/* <InputBase sx={{ ml: 2, flex: 1 }} placeholder="Search" /> */}
                <Stack spacing={5} direction="row" p={1}>
                    {/* <Button variant="text">Text</Button> */}
                    <Button variant="outlined" onClick={handleClick} size='large' style={{fontSize: '16px'}} sx={{width: 310, height: 50 , marginLeft: 2}}><b>Upload Demand Data</b></Button>
                    {/* <BasicMenu /> */}
                    {/* <Button variant="outlined">Outlined</Button> */}
                </Stack>
            </Box>
            </Box>
            <Header
              title="Current Demand data"//"CONTACTS"
              // subtitle="List of Contacts for Future Reference"
            />
            <ExcelTableNS filePath={table}/>

            {/* <RealtimeChecklist/> */}
            <RealtimeChecklist1/>

            <RunButton/>
            
        </Box>
        
    );
};

export default SCheduleOptimizer1;