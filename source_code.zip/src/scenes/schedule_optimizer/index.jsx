import Header from "../../components/Header";
import { Box, IconButton, useTheme } from "@mui/material";
import { useContext, useState } from "react";
import { ColorModeContext, tokens } from "../../theme";
import InputBase from "@mui/material/InputBase";
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import NotificationsOutlinedIcon from "@mui/icons-material/NotificationsOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import PersonOutlinedIcon from "@mui/icons-material/PersonOutlined";
import SearchIcon from "@mui/icons-material/Search";
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import BasicMenu from "../../components/DropDB";

const SCheduleOptimizer = () => {
    const theme = useTheme();
    const colors = tokens(theme.palette.mode);
    const colorMode = useContext(ColorModeContext);
    const handleClick = () => {
        window.location.href = '/schedule_optimizer1';
        };
    const handleFileUpload = () => {
    // Trigger file input click event
    document.getElementById('fileInput').click();
  };

//   const handleFileChange = (event) => {
//     // Handle file selection
//     const selectedFile = event.target.files[0];
//     console.log('Selected File:', selectedFile);
//     window.location.href = '/optimizer';
//     // You can perform further operations with the selected file here
//   };

    const [selectedFile, setSelectedFile] = useState(null);
  
    const handleFileChange = (event) => {
      const file = event.target.files[0];
      setSelectedFile(file);
      // Redirect to '/optimizer' after file selection
      window.location.href = '/schedule_optimizer1';
    };



    return (
        <Box m="20px">
            <Box display="flex" justifyContent="space-between" alignItems="center">
                <Header title="Schedule Optimizer" subtitle="" size="h2" />
            </Box>
            <Box display="flex" justifyContent="left" mb={2}>
            <Box
                display="flex"
                backgroundColor={colors.primary[400]}
                borderRadius="3px"
            >

                <>
                <input
                    type="file"
                    id="fileInput"
                    style={{ display: 'none' }}
                    onChange={handleFileChange}
                />
                </>


                {/* <InputBase sx={{ ml: 2, flex: 1 }} placeholder="Search" /> */}
                <Stack spacing={5} direction="row" p={1}>
                    {/* <Button variant="text">Text</Button> */}
                    <Button variant="outlined" onClick={handleFileUpload} size='large' style={{fontSize: '16px'}} sx={{width: 310, height: 50 , marginLeft: 2}}><b>Upload Demand Data</b></Button>
                    {/* <BasicMenu /> */}
                    {/* <Button variant="outlined">Outlined</Button> */}
                </Stack>
            </Box>
        </Box>
        </Box>
        
    );
};

export default SCheduleOptimizer;



// const UploadButton = () => {
//   const [selectedFile, setSelectedFile] = useState(null);

//   const handleFileChange = (event) => {
//     const file = event.target.files[0];
//     setSelectedFile(file);
//     // Redirect to '/optimizer' after file selection
//     window.location.href = '/optimizer';
//   };

//   return (
//     <div>
//       <input type="file" onChange={handleFileChange} />
//       <button onClick={() => setSelectedFile(null)}>Clear File</button>
//     </div>
//   );
// };

