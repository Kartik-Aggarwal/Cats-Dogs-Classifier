import Header from "../../components/Header";
import { Box, IconButton, useTheme } from "@mui/material";
import { useContext } from "react";
import { ColorModeContext, tokens } from "../../theme";
import InputBase from "@mui/material/InputBase";
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import NotificationsOutlinedIcon from "@mui/icons-material/NotificationsOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import PersonOutlinedIcon from "@mui/icons-material/PersonOutlined";
import SearchIcon from "@mui/icons-material/Search";
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import BasicMenu from "../../components/DropDB";

const RouteOptimizer = () => {
    const theme = useTheme();
    const colors = tokens(theme.palette.mode);
    const colorMode = useContext(ColorModeContext);
    const handleClick = () => {
        window.location.href = '/route_optimizer1';
        };

    return (
        <Box m="20px">
            <Box display="flex" justifyContent="space-between" alignItems="center">
                <Header title="Route Optimizer" subtitle="" />
            </Box>
            <Box display="flex" justifyContent="left" mb={2}>
            <Box
                display="flex"
                backgroundColor={colors.primary[400]}
                borderRadius="3px"
            >
                {/* <InputBase sx={{ ml: 2, flex: 1 }} placeholder="Search" /> */}
                <Stack spacing={5} direction="row" p={1}>
                    {/* <Button variant="text">Text</Button> */}
                    <Button variant="outlined" onClick={handleClick} size='large' style={{fontSize: '16px'}} sx={{width: 310, height: 50 , marginLeft: 2}}><b>Upload Schedule</b></Button>
                    {/* <BasicMenu /> */}
                    {/* <Button variant="outlined">Outlined</Button> */}
                </Stack>
            </Box>
        </Box>
        </Box>
        
    );
};

export default RouteOptimizer;


