import Header from "../../components/Header";
import { Box, CircularProgress, IconButton, useTheme } from "@mui/material";
import { useContext, useState } from "react";
import { ColorModeContext, tokens } from "../../theme";
import InputBase from "@mui/material/InputBase";
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import NotificationsOutlinedIcon from "@mui/icons-material/NotificationsOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import PersonOutlinedIcon from "@mui/icons-material/PersonOutlined";
import SearchIcon from "@mui/icons-material/Search";
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import BasicMenu from "../../components/DropDB";
import DemandData from "../demand_data";
import SelectTextFields from "../../components/DropDownMenu";
import RealtimeChecklist2I from "../../components/CheckList2_copy_routeI";
import RealtimeChecklist2C from "../../components/CheckList2_copy_routeC";
import table from '../../components/tables/DeliveryAll.xlsx'
import ExcelTableNS from "../../components/ExcelTableNoSelect";
import MapsResult from "./mapsRouteResult";


const RouteOptimizer1 = () => {
    const obj_func = [
        {
          value: 'USD',
          label: 'Minimise Cost',
        },
        // {
        //   value: 'EUR',
        //   label: 'Maximise Profit',
        // },
        {
          value: 'BTC',
          label: 'Minimise Time',
        },
        // {
        //   value: 'JPYb',
        //   label: 'Maximise Efficiency',
        // },
        // {
        //   value: 'JPYa',
        //   label: 'Minimise Distance',
        // },
      ];
    const algo = [
        {
          value: 'USDa',
          label: 'Previously Used Algorithm',
        },
        {
          value: 'USD',
          label: 'Choose Best Algorithm',
        },
        // {
        //   value: 'EUR',
        //   label: 'Non Linear Programming',
        // },
        // {
        //   value: 'BTC',
        //   label: 'Genetic Algorithm',
        // },
        // {
        //   value: 'JPYa',
        //   label: 'Particle Swarm Optimization', 
        // },
        // {
        //   value: 'JPYb',
        //   label: 'Step Optimization',
        // },
        // {
        //   value: 'JPYc',
        //   label: 'Custom Heuristic',
        // },
      ];


    const [clicked, setClicked] = useState(false);
    const [clickedC, setClickedC] = useState(false);
    const [showMapResult, setShowMapsResult] = useState(false);
    const handleClickButt = () => {
        setTimeout(() => {
            setClicked(true);
        }, 2000);
    };

    const handleClickCompute = () => {
        setClickedC(true);
        setTimeout(() => {
        setShowMapsResult(true);
        }, 5000);
    };


    const theme = useTheme();
    const colors = tokens(theme.palette.mode);
    const colorMode = useContext(ColorModeContext);
    const handleClick = () => {
        window.location.href = '/route_optimizer1';
        };

    return (
        <Box m="20px">
            <Box display="flex" justifyContent="space-between" alignItems="center">
                <Header title="Route Optimizer" subtitle="" />
            </Box>
            
            <Box display="flex" justifyContent="left" mb={2}>
            <Box
                display="flex"
                backgroundColor={colors.primary[400]}
                borderRadius="3px"
            >
                {/* <InputBase sx={{ ml: 2, flex: 1 }} placeholder="Search" /> */}
                <Stack spacing={5} direction="row" p={1}>
                    {/* <Button variant="text">Text</Button> */}
                    <Button variant="outlined" onClick={handleClick} size='large' style={{fontSize: '16px'}} sx={{width: 310, height: 50 , marginLeft: 2}}><b>Upload Schedule</b></Button>
                    {/* <BasicMenu /> */}
                    {/* <Button variant="outlined">Outlined</Button> */}
                </Stack>
            </Box>
            </Box>
            <ExcelTableNS filePath={table}/>
            <RealtimeChecklist2I/>
            <RealtimeChecklist2C/>
            <div style={{display:'flex', flexDirection: 'row', justifyContent: 'space-around', padding: '70px 5px 25px 5px'}}>
            {/* <Button variant="outlined" onClick={handleClickButt} size='large' style={{fontSize: '16px'}} sx={{width: 310, height: 60 , marginLeft: 2}}><b>{clicked ? 'Constraints Added': 'Add Constraints'}</b></Button> */}
            <SelectTextFields label={'Choose Objective Function'} dict={obj_func}/>
            <SelectTextFields label={'Choose Algorithm'} dict={algo}/>

            </div>
            {/* <div style={{display:'flex', flexDirection: 'row', justifyContent: 'space-evenly', padding: '40px 5px 25px 5px'}}>
            <SelectTextFields label={'Select your objective function'} dict={obj_func}/>
            <SelectTextFields label={'Select Algorithm'} dict={algo}/>
            </div> */}
            <Box textAlign={'center'} style={{padding: 20, display:'flex', flexDirection: 'row', justifyContent: 'center',}}>
            <Button variant="outlined" onClick={handleClickCompute} size='large' style={{fontSize: '16px'}} sx={{width: 310, height: 60 , marginLeft: 2}}><b>{(clickedC && (!showMapResult)) ? 'Running Route Optimizer...': 'Run Route Optimizer'}</b></Button>
            <div style={{marginLeft: 30}}>{(clickedC && (!showMapResult)) && <CircularProgress size={50} />}</div> {/* Show loading indicator while checking items */}
            </Box>
            
            {showMapResult && <MapsResult/>}
            
            
        </Box>
        
    );
};

export default RouteOptimizer1;


