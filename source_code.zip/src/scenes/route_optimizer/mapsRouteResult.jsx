import { Box, Button, Typography } from "@mui/material";
import Header from "../../components/Header";
import FlipCardR from "../../components/FlipCardR/FlipCardR";
import ActionAreaCard from "../../components/card/Card1";
import FlipCard from "../../components/flipcard/FlipCard";
import img1 from "./../../components/assets/photos/CScreenshot 2024-05-02 214237.png";
import img2 from "./../../components/assets/photos/Screenshot 2024-05-03 203419.png";
import img3 from "./../../components/assets/photos/Screenshot 2024-05-03 203606.png";
import ActionAreaCard2 from "../../components/card/Card2";
import { useState } from "react";
// import table2 from './tables/Delivery2.xlsx'
import table3 from '../../components/tables/Service1.xlsx'
// import table4 from './tables/Service2.xlsx'
import routeD1 from '../../components/tables/routeDelivery1.xlsx'
import routeD2 from '../../components/tables/routeDelivery2.xlsx'
import routeD3 from '../../components/tables/routeDelivery3.xlsx'
import routeS1 from '../../components/tables/routeService1.xlsx'
import routeS2 from '../../components/tables/routeService2.xlsx'
import routeS3 from '../../components/tables/routeService3.xlsx'
// import routeD1 from '../../components/tables/routeDelivery1.xlsx'
// import routeD2 from '../../components/tables/routeDelivery2.xlsx'
import ExcelTableNS from "../../components/ExcelTableNoSelect";


const MapsResult = () => {
    const [buttonPressed, setButtonPressed] = useState(false);
    const handleClick = (buttonName) => {
        setButtonPressed(buttonName)
    };

    return (
        <Box m="20px">
            {/* <Box display="flex" justifyContent="space-between" alignItems="center">
                <Header title="Objectives of Scheduling and Route Optimization" subtitle="" />
            </Box> */}
            
            {/* <div style={{display:'flex', flexDirection: 'row', gap: '114px', gap: 10, justifyContent: 'space-between', padding: '40px 5px 25px 5px'}}>
            <FlipCard img={img3}/>
            <FlipCard img={img2} content={""} heading='Minimize time taken to complete the route' back={'Efficiency in logistics requires minimizing the time taken to complete a route. By considering factors such as traffic patterns and optimal sequencing of stops, route optimization software can calculate the quickest route. This reduces delivery times and enables sales representatives to attend more meetings or visits within a given time frame, enhancing overall operational efficiency.'}/>
            <FlipCard img={img1} content={''} heading='Accommodate dynamic changes in the route efficiently to adapt to real-time conditions' back={'Real-time adaptability is crucial in logistics due to unforeseen events like traffic congestion or new customer requests. Route optimization systems employ dynamic algorithms that can swiftly recalculate routes based on changing conditions. This adaptability ensures that sales representatives can adjust their routes on-the-go, maintaining efficiency and customer satisfaction while responding promptly to evolving circumstances.'}/>
            
            </div> */}
            <div>
            <div style={{ display: 'flex', flexDirection: 'row', gap: '54px', justifyContent: 'space-between', padding: '40px 5px 25px 5px' }}>
                <div style={{ textAlign: 'center' }}>
                <h2>DC306 - New York</h2>
                <Button onClick={() => handleClick("Button 1")} sx={{ width: 350, height: 255, borderRadius: '1.2rem', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <ActionAreaCard2 img={img1} />
                </Button>
                </div>
                <div style={{ textAlign: 'center' }}>
                <h2>DC313 - Chicago</h2>
                <Button onClick={() => handleClick("Button 2")} sx={{ width: 350, height: 255, borderRadius: '1.2rem', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <ActionAreaCard2 img={img2} />
                </Button>
                </div>
                <div style={{ textAlign: 'center' }}>
                <h2>DC301 - Los Angeles</h2>
                <Button onClick={() => handleClick("Button 3")} sx={{ width: 350, height: 255, borderRadius: '1.2rem', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <ActionAreaCard2 img={img3} />
                </Button>
                </div>
            </div>
            </div>

            {buttonPressed === 'Button 1' && (<><Header size='h3' title={'Delivery Schedule for DC306'} /><ExcelTableNS filePath={routeD1} flag={true}/>
            <div style={{ height: '20px'}} />
            <Header size='h3' title={'Service Schedule for DC306'} /><ExcelTableNS filePath={routeS1} flag={true}/></>)}
            
            {buttonPressed === 'Button 2' && (<><Header size='h3' title={'Delivery Schedule for DC313'} /><ExcelTableNS filePath={routeD2} flag={true}/>
            <div style={{ height: '20px'}} />
            <Header size='h3' title={'Service Schedule for DC313'} /><ExcelTableNS filePath={routeS2} flag={true}/></>)}
            
            {buttonPressed === 'Button 3' && (<><Header size='h3' title={'Delivery Schedule for DC301'} /><ExcelTableNS filePath={routeD3} flag={true}/>
            <div style={{ height: '20px'}} />
            <Header size='h3' title={'Service Schedule for DC301'} /><ExcelTableNS filePath={routeS3} flag={true}/></>)}
            
            {/* {buttonPressed === 'Button 3' && (<><Header size='h3' title={'Delivery Schedule'} /><ExcelTableNS filePath={table1}/>
            <div style={{ height: '20px'}} />
            <Header size='h3' title={'Service Schedule'} /><ExcelTableNS filePath={table3}/></>)} */}

            {/* <div style={{display:'flex', flexDirection: 'row', gap: '114px', gap: 10, justifyContent: 'space-between'}}>
            <ActionAreaCard/>
            <ActionAreaCard/>
            <ActionAreaCard/>
            </div> */}

            
        </Box>
    );
};

export default MapsResult;