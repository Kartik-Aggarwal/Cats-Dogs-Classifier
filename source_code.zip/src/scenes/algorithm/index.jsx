import { Box } from "@mui/material";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { tokens } from "../../theme";
import Header from "../../components/Header";
import { useTheme } from "@mui/material";
import { mockDataAlgorithm } from "../../data/mockData";

const Algorithm = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const columns = [
    { field: "id", headerName: "ID", flex: 0.05 },
    { field: "Algorithm", headerName: "Algorithm" , flex: 0.2},
    {
      field: "Computation Time",
      headerName: "Computation Time",
      flex: 0.1,
      cellClassName: "name-column--cell",
    },
    {
      field: "Accuracy",
      headerName: "Accuracy",
      type: "number",
      headerAlign: "left",
      align: "left",
      flex: 0.1
    },
    {
        field: "Scalibility",
        headerName: "Scalibility",
        type: "number",
        headerAlign: "left",
        align: "left",
        flex: 0.1
      },
    {
      field: "Idea for",
      headerName: "Idea for",
      type: "number",
      headerAlign: "left",
      align: "left",
      flex: 0.4
    },
  ];

  return (
    <Box m="20px">
      <Header
        // title="Algorithms"//"CONTACTS"
        // subtitle="List of Contacts for Future Reference"
      />
      <Box
        m="40px 0 0 0"
        height="75vh"
        sx={{
            "& .MuiDataGrid-root": {
              border: "none",
              fontSize: 20
            },
            "& .MuiDataGrid-cell": {
              borderBottom: "none",
              fontSize: 15    
            },
            "& .name-column--cell": {
              color: colors.greenAccent[300],
            },
            "& .MuiDataGrid-columnHeaders": {
              backgroundColor: colors.blueAccent[700],
              borderBottom: "none",
            },
            "& .MuiDataGrid-virtualScroller": {
              backgroundColor: colors.primary[400],
            },
            "& .MuiDataGrid-footerContainer": {
              borderTop: "none",
              backgroundColor: colors.blueAccent[700],
            },
            "& .MuiCheckbox-root": {
              color: `${colors.greenAccent[200]} !important`,
            },
            "& .MuiDataGrid-toolbarContainer .MuiButton-text": {
              color: `${colors.grey[100]} !important`,
            },
          }}
        >
          <style>
          {/* {`
            .MuiDataGrid-root .MuiDataGrid-colCellWrapper,
            .MuiDataGrid-root .MuiDataGrid-cell {
              border-right: 1px solid #e0e0e0;
              border-bottom: 1px solid #e0e0e0;
            }
          `} */}
        </style>
        <DataGrid
          rows={mockDataAlgorithm}
          columns={columns}
          density="comfortable"
        //   initialState={{
        //     density: 'comfortable'}}
          components={{ Toolbar: GridToolbar }}
        />
      </Box>
    </Box>
  );
};

export default Algorithm;
