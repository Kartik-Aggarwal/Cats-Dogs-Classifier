import { Box, Button, IconButton, Typography, useTheme } from "@mui/material";
import { tokens } from "../../theme";
import { mockTransactions } from "../../data/mockData";
import DownloadOutlinedIcon from "@mui/icons-material/DownloadOutlined";
import EmailIcon from "@mui/icons-material/Email";
import PointOfSaleIcon from "@mui/icons-material/PointOfSale";
import PersonAddIcon from "@mui/icons-material/PersonAdd";
import TrafficIcon from "@mui/icons-material/Traffic";
import Header from "../../components/Header";
import LineChart1 from "../../components/LineChart1";
// import GeographyChart from "..a/../components/GeographyChart";
import BarChartHor from "../../components/BarChartHor";
import BarChartFromCSV from "../../components/BarChartFromCsv";
import StatBox from "../../components/StatBox";
import StatBox1 from "../../components/StatBox1";
import ProgressCircle from "../../components/ProgressCircle";
import TopbarMini from "../global/TopbarMini";
import TempTopBar from "../../components/TempTopbar";
import S_StatBox1 from "../../components/S_StatBox_1";
import Y_StatBox1 from "../../components/Y_StatBox_1";

const Inventory = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <Box m="20px">
      {/* HEADER */}
      <Box display="flex" justifyContent="space-between" alignItems="center">
        <Header title="Optimisation Problem" subtitle="" />


      </Box>
      <TopbarMini />
    </Box>
  );
};

export default Inventory;