import { useState } from "react";
import { ProSidebar, Menu, MenuItem } from "react-pro-sidebar";
import { Box, IconButton, Typography, useTheme } from "@mui/material";
import { Link } from "react-router-dom";
import "react-pro-sidebar/dist/css/styles.css";
import { tokens } from "../../theme";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import PeopleOutlinedIcon from "@mui/icons-material/PeopleOutlined";
import ContactsOutlinedIcon from "@mui/icons-material/ContactsOutlined";
import ReceiptOutlinedIcon from "@mui/icons-material/ReceiptOutlined";
import PersonOutlinedIcon from "@mui/icons-material/PersonOutlined";
import CalendarTodayOutlinedIcon from "@mui/icons-material/CalendarTodayOutlined";
import HelpOutlineOutlinedIcon from "@mui/icons-material/HelpOutlineOutlined";
import BarChartOutlinedIcon from "@mui/icons-material/BarChartOutlined";
import PieChartOutlineOutlinedIcon from "@mui/icons-material/PieChartOutlineOutlined";
import TimelineOutlinedIcon from "@mui/icons-material/TimelineOutlined";
import MenuOutlinedIcon from "@mui/icons-material/MenuOutlined";
import MapOutlinedIcon from "@mui/icons-material/MapOutlined";
import 'react-pro-sidebar/dist/css/styles.css';
import RouteIcon from '@mui/icons-material/Route';
import ChecklistIcon from '@mui/icons-material/Checklist';
import FmdBadIcon from '@mui/icons-material/FmdBad';
import InputIcon from '@mui/icons-material/Input';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import AutorenewIcon from '@mui/icons-material/Autorenew';





const Item = ({ title, to, icon, selected, setSelected }) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <MenuItem
      active={selected === title}
      style={{
        color: colors.grey[100],
        width: '100%', wordBreak: 'break-all'
      }}
      onClick={() => setSelected(title)}
      icon={icon}
    >
      <Typography>{title}</Typography>
      <Link to={to} />
    </MenuItem>
  );
};



const Sidebar = ({ isCollapsed, onToggleSidebar }) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  // const [isCollapsed, setIsCollapsed] = useState(false);
  const [selected, setSelected] = useState("Dashboard");

  return (
    <Box
      sx={{
        "& .pro-sidebar-inner": {
          background: `${colors.primary[400]} !important`,
        },
        "& .pro-icon-wrapper": {
          backgroundColor: "transparent !important",
        },
        "& .pro-inner-item": {
          padding: "5px 35px 5px 10px !important",
        },
        "& .pro-inner-item:hover": {
          color: "#868dfb !important",
        },
        "& .pro-menu-item.active": {
          color: "#6870fa !important",
        },
      }}
    >
      <div style={{display: 'flex', height: '100vh' }}>
      <ProSidebar collapsed={isCollapsed} width={240} collapsedWidth={70} style={{flex: '0 0 auto', position: 'fixed', height: '100vh' }}>
        <Menu iconShape="square">
          {/* LOGO AND MENU ICON */}
          <MenuItem
            onClick={onToggleSidebar}
            icon={isCollapsed ? <MenuOutlinedIcon /> : undefined}
            style={{
              margin: "10px 0 20px 0",
              color: colors.grey[100],
            }}
          >
            {!isCollapsed && (
              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                ml="15px"
              >
                <Typography variant="h3" color={colors.grey[100]}>
                  ADMINS
                </Typography>
                <IconButton onClick={onToggleSidebar}>
                  <MenuOutlinedIcon />
                </IconButton>
              </Box>
            )}
          </MenuItem>

          {!isCollapsed && (
            <Box mb="25px">
              {/* <Box display="flex" justifyContent="center" alignItems="center">
                <img
                  alt="profile_img"
                  width="100px"
                  height="100px"
                  src={`../../assets/towers.jpg`}
                  style={{ cursor: "pointer", borderRadius: "50%" }}
                />
              </Box> */}
              <Box textAlign="center">
                <Typography
                  variant="h2"
                  color='#fb4e0b'
                  fontWeight="bold"
                  sx={{ m: "10px 0 0 0" }}
                >
                  EXL
                </Typography>
                <Typography variant="h5" color={colors.primary[100]}>
                  {/* Lorem ipsum */}
                </Typography>
              </Box>
            </Box>
          )}

          <Box paddingLeft={isCollapsed ? undefined : "10%"} style={{ wordBreak: "break-all"}}>
          

            <Item
              title="Home"
              to="/"
              icon={<HomeOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />

            <Typography
              variant="h6"
              color={colors.grey[300]}
              sx={{ m: "15px 0 5px 20px" }}
            >
              {/* {isCollapsed ? 'Route \n Op.' : 'Route Optimisation'} */}
            </Typography>
            {/* <Item
              title="Optimisation Problem"
              to="/inventory"
              icon={<PeopleOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
              style={{ width: "100%"}}
              overflowWrap
            /> */}
            {/* <Item
              title="Objectives"
              to="/objectives"
              icon={<ChecklistIcon />}
              selected={selected}
              setSelected={setSelected}
            /> */}
            {/* <Item
              title="Constraints"
              to="/constraints"
              icon={<FmdBadIcon />}
              selected={selected}
              setSelected={setSelected}
            /> */}
            {/* <Item
              title="Input Tables"
              to="/model_inputs_tab"
              icon={<InputIcon />}
              selected={selected}
              setSelected={setSelected}
            /> */}
            <MenuItem
              active={selected === "Input Tables/Constraints"}
              style={{
                color: colors.grey[100],
                width: '100%', wordBreak: 'break-all'
              }}
              onClick={() => setSelected("Input Tables/Constraints")}
              icon={<InputIcon/>}
            >
              <Typography>Input Tables/</Typography>
              <Typography>Constraints</Typography>
              <Link to="/model_inputs_tab" />
            </MenuItem>
            <Item
              title="Algorithms"
              to="/work_queues"
              icon={<ContactsOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="Schedule Optimizer"
              to="/schedule_optimiz"
              icon={<CalendarMonthIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="Route Optimizer"
              to="/route_optimizer"
              icon={<RouteIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            {/* <Item
              title="Dynamic Route Optimizer"
              to="/dynamic_route_optimizer"
              icon={<AutorenewIcon />}
              selected={selected}
              setSelected={setSelected}
            /> */}
            <MenuItem
              active={selected === "Dynamic Route Optimizer"}
              style={{
                color: colors.grey[100],
                width: '100%', wordBreak: 'break-all'
              }}
              onClick={() => setSelected("Dynamic Route Optimizer")}
              icon={<AutorenewIcon/>}
            >
              <Typography>Dynamic Route</Typography>
              <Typography>Optimizer</Typography>
              <Link to="/dynamic_route_optimizer" />
            </MenuItem>
            {/* <Item
              title="temporary"
              to="/temp"
              icon={<RouteIcon />}
              selected={selected}
              setSelected={setSelected}
            /> */}
            
            
            
            {/* <Item
              title="Model Inputs"
              to="/model_inputs"
              icon={<InputIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="Solutions Methods"
              to="/data_explorer"
              icon={<ReceiptOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            /> */}
            
            

          </Box>
        </Menu>
      </ProSidebar>
      </div>
    </Box>
  );
};

export default Sidebar;