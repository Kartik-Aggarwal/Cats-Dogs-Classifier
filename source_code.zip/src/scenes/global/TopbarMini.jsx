import { Box, IconButton, useTheme } from "@mui/material";
import { useContext, useState } from "react";
import { ColorModeContext, tokens } from "../../theme";
import InputBase from "@mui/material/InputBase";
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import NotificationsOutlinedIcon from "@mui/icons-material/NotificationsOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import PersonOutlinedIcon from "@mui/icons-material/PersonOutlined";
import SearchIcon from "@mui/icons-material/Search";
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import BasicMenu from "../../components/DropDB";



const TopbarMini = ({ buttonSelected }) => {

  const [activeButton, setActiveButton] = useState(buttonSelected);
    const theme = useTheme();
    const colors = tokens(theme.palette.mode);
    const colorMode = useContext(ColorModeContext);
    const handleClick1 = () => {
      setActiveButton('button1')
        window.location.href = '/ProductTable';
        };
    const handleClick2 = () => {
      setActiveButton('button2')
    window.location.href = '/InventoryTable';
    };
    const handleClick3 = () => {
        setActiveButton('button3')
        window.location.href = '/DCTable';
        };
    const handleClick4 = () => {
      setActiveButton('button4')
    window.location.href = '/TechniciansTable';
    };
    const handleClick5 = () => {
      setActiveButton('button5')
      window.location.href = '/VehicleTable';
      };
    const handleClick6 = () => {
      setActiveButton('button6')
      window.location.href = '/DriverTable';
      };
    const handleClick7 = () => {
      setActiveButton('button7')
      window.location.href = '/DeliveryLaborTable';
      };
  return (
    <Box display="flex" justifyContent="space-around" mb={2} marginBottom={2} sx={{border:1, borderColor:'#ddd', borderRadius: 10, backgroundColor: '#EEF4FF'}}>
      {/* <Box
        display="flex"
        // backgroundColor={colors.primary[400]}
        borderRadius="3px"
        justifyContent='space-between'
      > */}
        {/* <InputBase sx={{ ml: 2, flex: 1 }} placeholder="Search" /> */}
        <Stack spacing={3} direction="row" p={1} width='100%' display="flex" justifyContent="space-around" paddingLeft={3} paddingRight={3}>
            {/* <Button variant="text">Text</Button> */}
            <Button variant="outlined" onClick={() => handleClick3('button3')}  sx={{width: '165px', backgroundColor: activeButton === 'button3' ? '#FF670B' : '#FFE8E1', transition: 'background-color 0.3s color 0.3s', color: activeButton === 'button3' ? 'white' : 'black', '&:hover': {boxShadow:4, backgroundColor: '#FF670B', color: 'white'}}}><b>Distribution Centers Details</b></Button>
            <Button variant="outlined" onClick={() => handleClick1('button3')}  sx={{width: '165px', backgroundColor: activeButton === 'button1' ? '#FF670B' : '#FFE8E1', transition: 'background-color 0.3s color 0.3s', color: activeButton === 'button1' ? 'white' : 'black', '&:hover': {boxShadow:4, backgroundColor: '#FF670B', color: 'white'}}}><b>Product Master</b></Button>
            <Button variant="outlined" onClick={() => handleClick2('button3')}  sx={{width: '165px', backgroundColor: activeButton === 'button2' ? '#FF670B' : '#FFE8E1', transition: 'background-color 0.3s color 0.3s', color: activeButton === 'button2' ? 'white' : 'black', '&:hover': {boxShadow:4, backgroundColor: '#FF670B', color: 'white'}}}><b>Inventory</b></Button>
            <Button variant="outlined" onClick={() => handleClick5('button3')}  sx={{width: '165px', backgroundColor: activeButton === 'button5' ? '#FF670B' : '#FFE8E1', transition: 'background-color 0.3s color 0.3s', color: activeButton === 'button5' ? 'white' : 'black', '&:hover': {boxShadow:4, backgroundColor: '#FF670B', color: 'white'}}}><b>Truck Details</b></Button>
            <Button variant="outlined" onClick={() => handleClick6('button3')}  sx={{width: '165px', backgroundColor: activeButton === 'button6' ? '#FF670B' : '#FFE8E1', transition: 'background-color 0.3s color 0.3s', color: activeButton === 'button6' ? 'white' : 'black', '&:hover': {boxShadow:4, backgroundColor: '#FF670B', color: 'white'}}}><b>Driver Information</b></Button>
            <Button variant="outlined" onClick={() => handleClick7('button3')}  sx={{width: '165px', backgroundColor: activeButton === 'button7' ? '#FF670B' : '#FFE8E1', transition: 'background-color 0.3s color 0.3s', color: activeButton === 'button7' ? 'white' : 'black', '&:hover': {boxShadow:4, backgroundColor: '#FF670B', color: 'white'}}}><b>Delivery Staff Details</b></Button>
            <Button variant="outlined" onClick={() => handleClick4('button3')}  sx={{width: '165px', backgroundColor: activeButton === 'button4' ? '#FF670B' : '#FFE8E1', transition: 'background-color 0.3s color 0.3s', color: activeButton === 'button4' ? 'white' : 'black', '&:hover': {boxShadow:4, backgroundColor: '#FF670B', color: 'white'}}}><b>Technicians/Engineer Information</b></Button>

            {/* <BasicMenu /> */} 
            {/* <Button variant="outlined">Outlined</Button> */}
        </Stack>
      {/* </Box> */}
    </Box>
  );
};

export default TopbarMini;