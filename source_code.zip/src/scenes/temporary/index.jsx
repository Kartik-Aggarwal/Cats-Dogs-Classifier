import Header from "../../components/Header";
import { Box, Button, IconButton, Typography, useTheme } from "@mui/material";
import { tokens } from "../../theme";
import { mockTransactions } from "../../data/mockData";
import DownloadOutlinedIcon from "@mui/icons-material/DownloadOutlined";
import EmailIcon from "@mui/icons-material/Email";
import PointOfSaleIcon from "@mui/icons-material/PointOfSale";
import PersonAddIcon from "@mui/icons-material/PersonAdd";
import TrafficIcon from "@mui/icons-material/Traffic";
import LineChart1 from "../../components/LineChart1";
import GeographyChart from "../../components/GeographyChart";
import BarChart from "../../components/BarChart";
import StatBox from "../../components/StatBox";
import ProgressCircle from "../../components/ProgressCircle";
import Topbar from "../../scenes/global/Topbar"
import TopbarMini from "../global/TopbarMini";
import TempTopBar from "../../components/TempTopbar";
import ExcelTable from "../../components/ExcelTable";
import { useState } from "react";

const Temp = () => {
    const [selectedFile, setSelectedFile] = useState(null);
  
    const handleFileChange = (event) => {
      const file = event.target.files[0];
      setSelectedFile(file);
      // Redirect to '/optimizer' after file selection
      window.location.href = '/optimizer';
    };
  
    return (
      <div>
        <input type="file" onChange={handleFileChange} />
        <button onClick={() => setSelectedFile(null)}>Clear File</button>
      </div>
    );
  };
export default Temp;