import Header from "../../components/Header";
import { Box, Button, Stack, Typography, useTheme } from "@mui/material";
import { tokens } from "../../theme";
import { mockTransactions } from "../../data/mockData";
import DownloadOutlinedIcon from "@mui/icons-material/DownloadOutlined";
import EmailIcon from "@mui/icons-material/Email";
import PointOfSaleIcon from "@mui/icons-material/PointOfSale";
import PersonAddIcon from "@mui/icons-material/PersonAdd";
import TrafficIcon from "@mui/icons-material/Traffic";
import LineChart1 from "../../components/LineChart1";
import GeographyChart from "../../components/GeographyChart";
import BarChart from "../../components/BarChart";
import StatBox from "../../components/StatBox";
import ProgressCircle from "../../components/ProgressCircle";
import Topbar from "../../scenes/global/Topbar"
import TopbarMini from "../global/TopbarMini";
import TempTopBar from "../../components/TempTopbar";
import ExcelTable from "../../components/ExcelTable";
import { useState } from "react";
import ExcelTableCheck from "../../components/ExcelTableCheck";
import table from "./AlgorithmTable.xlsx"
import { IconButton } from "@mui/material";
import { useContext } from "react";
import { ColorModeContext } from "../../theme";

const DRO = () => {
    const theme = useTheme();
    const colors = tokens(theme.palette.mode);
    const colorMode = useContext(ColorModeContext);

    const handleFileUpload = () => {
        // Trigger file input click event
        document.getElementById('fileInput').click();
      };
    
    //   const handleFileChange = (event) => {
    //     // Handle file selection
    //     const selectedFile = event.target.files[0];
    //     console.log('Selected File:', selectedFile);
    //     window.location.href = '/optimizer';
    //     // You can perform further operations with the selected file here
    //   };
    
        const [selectedFile, setSelectedFile] = useState(null);
      
        const handleFileChange = (event) => {
          const file = event.target.files[0];
          setSelectedFile(file);
          // Redirect to '/optimizer' after file selection
          window.location.href = '/dynamic_route_optimizer1';
        };

    return (
        <Box m="20px">
            <Box display="flex" justifyContent="space-between" alignItems="center">
                <Header title="Dynamic Route Optimizer" subtitle="" size="h2" />
            </Box>
            <Box display="flex" justifyContent="left" mb={2}>
            <Box
                display="flex"
                backgroundColor={colors.primary[400]}
                borderRadius="3px"
            >

                <>
                <input
                    type="file"
                    id="fileInput"
                    style={{ display: 'none' }}
                    onChange={handleFileChange}
                />
                </>


                {/* <InputBase sx={{ ml: 2, flex: 1 }} placeholder="Search" /> */}
                <Stack spacing={5} direction="row" p={1}>
                    {/* <Button variant="text">Text</Button> */}
                    <Button variant="outlined" onClick={handleFileUpload} size='large' style={{fontSize: '16px'}} sx={{width: 310, height: 50 , marginLeft: 2}}><b>Upload Route</b></Button>
                    {/* <BasicMenu /> */}
                    {/* <Button variant="outlined">Outlined</Button> */}
                </Stack>
            </Box>
        </Box>
        </Box>
        );
      };
    
export default DRO;