import { Box } from "@mui/material";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { tokens } from "../../theme";
import { mockDataCustomernOrder, mockDataDemandData } from "../../data/mockData";
import Header from "../../components/Header";
import { useTheme } from "@mui/material";

const DemandData = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const columns = [
    { field: "id", headerName: "ID", flex: 0.05 },
    { field: "Type", headerName: "Demand Type", flex: 0.2},
    {
      field: "Citycode",
      headerName: "Citycode",
      flex: 0.2,
      cellClassName: "name-column--cell",
    },
    {
      field: "ProductCategory",
      headerName: "Product Category",
      type: "number",
      headerAlign: "left",
      align: "left", flex: 0.2
    },
    {
      field: "Pincode",
      headerName: "Pincode",
      flex: 0.2,
    },
    {
      field: "Availabletime",
      headerName: "Available time",
      flex: 0.2,
    },
  ];

  return (
    <Box m="20px">
      <Header
        title="Schedule Data"//"CONTACTS"
        // subtitle="List of Contacts for Future Reference"
      />
      <Box
        m="40px 0 0 0"
        height="50vh"
        width="150vh"
        sx={{
          "& .MuiDataGrid-root": {
            border: "none",
            fontSize: 17
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
            fontSize: 15    
          },
          "& .name-column--cell": {
            color: colors.greenAccent[300],
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blueAccent[700],
            borderBottom: "none",
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.primary[400],
          },
        //   "& .MuiDataGrid-footerContainer": {
        //     borderTop: "none",
        //     backgroundColor: colors.blueAccent[700],
        //   },
          "& .MuiCheckbox-root": {
            color: `${colors.greenAccent[200]} !important`,
          },
          "& .MuiDataGrid-toolbarContainer .MuiButton-text": {
            color: `${colors.grey[100]} !important`,
          },
        }}
      >
        <style>
        {`
          .MuiDataGrid-root .MuiDataGrid-colCellWrapper,
          .MuiDataGrid-root .MuiDataGrid-cell {
            border-right: 1px solid #e0e0e0;
            border-bottom: 1px solid #e0e0e0;
          }
        `}
      </style>
        <DataGrid
          rows={mockDataDemandData}
          columns={columns}
        //   components={{ Toolbar: GridToolbar }}
        />
      </Box>
    </Box>
  );
};

export default DemandData;