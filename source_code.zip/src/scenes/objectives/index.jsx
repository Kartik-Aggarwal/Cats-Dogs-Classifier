import { Box, Typography } from "@mui/material";
import Header from "../../components/Header";
import FlipCardR from "../../components/FlipCardR/FlipCardR";
import ActionAreaCard from "../../components/card/Card1";
import FlipCard from "../../components/flipcard/FlipCard";
import img1 from "./../../components/assets/photos/Image result for images related to Routing optimization.jpg";
import img2 from "./../../components/assets/photos/image (2).png";
import img3 from "./../../components/assets/photos/marcin-jozwiak-oh0DITWoHi4-unsplash.jpg";
import img4 from "./../../components/assets/photos/14819.jpg";
import img5 from "./../../components/assets/photos/2147793520.jpg";
import img6 from "./../../components/assets/photos/14819 (1).jpg";

import Advantages from "../../components/Advantages";


const Objectives = () => {

    const advantagesList = [
        "Cost reduction due to the most efficient routes meeting demand and constraints",
        "Improved customer satisfaction and retention through meeting delivery windows and providing accurate ETA",
        "Enhanced performance for drivers through reducing driving time and stress",
        "Increased sustainability by lowering CO2 emissions, noise pollution, and congestion",
        "Dynamic routing can help support green initiatives such as electric vehicles or low-emission zones"
      ];

      
    return (
        <Box m="20px">
            <Box display="flex" justifyContent="space-between" alignItems="center">
                <Header title="Scheduling and Routing Optimization" subtitle="" />
            </Box>
            
            <div style={{display:'flex', flexDirection: 'row', gap: '114px', gap: 10, justifyContent: 'space-between', padding: '40px 5px 25px 5px'}}>
            <FlipCard img={img4} content={''} heading='Objective of Scheduling Optimization ' back={'Scheduling entails taking orders or service requests, calculating how many employees (and vehicles) are needed to cover those orders, and appointing employees to orders during particular time windows. To execute smooth field delivery operations, scheduling is almost always required first'}/>
            <FlipCard img={img5} content={""} heading='Objective of Routing Optimization' back={'Considering the delivery schedule and charting out specific (and optimal) routes for delivery drivers or service professionals. Route planning is used to optimize routes by considering factors such as vehicle resource limitations, travel time, and transportation costs etc.'}/>
            <FlipCard img={img3} content={''} heading='How Scheduling and Routing optimization come together' back={'While both scheduling and routing have points of distinction, you can’t entirely separate them. Last-mile delivery relies on both to be effective and successful. Route planning fulfills the demands of scheduling, while optimization maximizes the efficiency of both'}/>
            </div>
            {/* <div style={{display:'flex', flexDirection: 'row', gap: '114px', gap: 10, justifyContent: 'space-between'}}>
            <ActionAreaCard/>
            <ActionAreaCard/>
            <ActionAreaCard/>
            </div> */}
            <div>
                <Advantages advantages={advantagesList} />
            </div>

            <Box gridColumn="span 6" gridRow="span 1" backgroundColor={'#f2f0f0'} display="flex" alignItems="center" justifyContent="center" 
            sx={{transition: 'background-color 0.3s', '&:hover': {backgroundColor: '#ddd', boxShadow:4}}}>
            {/* <Typography gutterBottom variant="h5" component="div">
            Improved efficiency

Delivery efficiency increases with optimization. It constantly identifies the best routes in real-time to reduce detours and choose the most effective routes. You can maximize the number of deliveries completed per route and increase overall operational productivity by minimizing travel time and optimizing the stops 
            </Typography> */}
            </Box>
        </Box>
    );
};

export default Objectives;