import { Box } from "@mui/material";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { tokens } from "../../theme";
import { mockDataCustomernOrder } from "../../data/mockData";
import Header from "../../components/Header";
import { useTheme } from "@mui/material";
import CustomernOrder from ".";
import TopbarMini from "../global/TopbarMini";


const CustomernOrderF = () => {
    
  
    return (
    <Box m="20px">
          {/* HEADER */}
          <Box display="flex" justifyContent="space-between" alignItems="center">
            <Header title="Model Inputs" subtitle="" />  
          </Box>
          <TopbarMini />
          <CustomernOrder/>
    </Box>
    );
  };
  
  export default CustomernOrderF;