import { Box } from "@mui/material";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { tokens } from "../../theme";
import { mockDataCustomernOrder } from "../../data/mockData";
import Header from "../../components/Header";
import { useTheme } from "@mui/material";

const CustomernOrder = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const columns = [
    { field: "id", headerName: "ID", flex: 0.5 },
    { field: "customerId", headerName: "Customer ID" },
    {
      field: "weight",
      headerName: "Order Weight(Kg)",
      flex: 1,
      cellClassName: "name-column--cell",
    },
    {
      field: "volume",
      headerName: "Order Volume",
      type: "number",
      headerAlign: "left",
      align: "left",
    },
    {
      field: "startTime",
      headerName: "Delivery Start Window",
      flex: 1,
    },
    {
      field: "endTime",
      headerName: "Delivery End Window",
      flex: 1,
    },
    {
      field: "priority",
      headerName: "Priority",
      flex: 1,
    }
  ];

  return (
    <Box m="20px">
      <Header
        title="Customer and Order data"//"CONTACTS"
        // subtitle="List of Contacts for Future Reference"
      />
      <Box
        m="40px 0 0 0"
        height="75vh"
        sx={{
          "& .MuiDataGrid-root": {
            border: "none",
            fontSize: 20
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
            fontSize: 15    
          },
          "& .name-column--cell": {
            color: colors.greenAccent[300],
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blueAccent[700],
            borderBottom: "none",
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.primary[400],
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "none",
            backgroundColor: colors.blueAccent[700],
          },
          "& .MuiCheckbox-root": {
            color: `${colors.greenAccent[200]} !important`,
          },
          "& .MuiDataGrid-toolbarContainer .MuiButton-text": {
            color: `${colors.grey[100]} !important`,
          },
        }}
      >
        <style>
        {`
          .MuiDataGrid-root .MuiDataGrid-colCellWrapper,
          .MuiDataGrid-root .MuiDataGrid-cell {
            border-right: 1px solid #e0e0e0;
            border-bottom: 1px solid #e0e0e0;
          }
        `}
      </style>
        <DataGrid
          rows={mockDataCustomernOrder}
          columns={columns}
          components={{ Toolbar: GridToolbar }}
        />
      </Box>
    </Box>
  );
};

export default CustomernOrder;